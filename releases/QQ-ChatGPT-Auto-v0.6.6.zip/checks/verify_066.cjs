"use strict";
const fs = require("node:fs");
const vm = require("node:vm");
const assert = require("node:assert/strict");
const source = fs.readFileSync(process.argv[2] || "release_066/v0.6.6.js", "utf8");
const plain = source.replace(/ui\.layout\([\s\S]*?\n\);/, "ui.layout();");
assert.notEqual(plain, source);
new vm.Script(plain);
let now=0, nodes=[], pkg="com.tencent.mobileqq", taps=[], onTap=null, onSleep=null, captures=0, logs=[];
let ocrOutput=[], imageFixture=null;
class Clock extends Date { static now(){return now;} }
function rect(left,top,right,bottom) {
    return {left,top,right,bottom,width(){return right-left;},height(){return bottom-top;},
        centerX(){return (left+right)/2;},centerY(){return (top+bottom)/2;}};
}
function node(value,bounds,options={}) {
    let t=value;
    return {packageName:()=>options.pkg||"com.tencent.mobileqq",className:()=>options.cls||"android.widget.TextView",
        visibleToUser:()=>options.visible!==false,enabled:()=>options.enabled!==false,
        clickable:()=>options.clickable!==false,text:()=>t,desc:()=>options.desc||"",bounds:()=>bounds,
        parent:()=>options.parent||null,click:()=>{taps.push([bounds.centerX(),bounds.centerY()]);if(onTap)onTap(bounds.centerX(),bounds.centerY());return true;},
        setText:s=>{if(options.failWrite)return false;t=s;if(options.onWrite)options.onWrite(s);return true;}};
}
function input(value="",bounds=rect(90,850,590,940),options={}) {
    return node(value,bounds,{cls:"android.widget.EditText",...options});
}
function query(filters={}) {
    return {
        className:s=>query({...filters,cls:s}),classNameMatches:s=>query({...filters,clsRe:s}),
        visibleToUser:s=>query({...filters,visible:s}),textMatches:s=>query({...filters,text:s}),
        descMatches:s=>query({...filters,desc:s}),desc:s=>query({...filters,desc:new RegExp("^"+s+"$")}),
        find(){let result=nodes.filter(n=>(!filters.pkg||n.packageName()===filters.pkg)&&
            (!filters.cls||n.className()===filters.cls)&&(!filters.clsRe||filters.clsRe.test(n.className()))&&
            (filters.visible===undefined||n.visibleToUser()===filters.visible)&&
            (!filters.text||filters.text.test(n.text()))&&(!filters.desc||filters.desc.test(n.desc())));
            return {size:()=>result.length,get:i=>result[i]};},
        exists(){return this.find().size()>0;}
    };
}
const savedFiles=new Map();
const ctx=vm.createContext({Math,String,Number,Array,Object,JSON,RegExp,Date:Clock,
    device:{width:720,height:1600},running:true,state:{lastBotText:"",lastWasInterjection:false,recentTurns:[]},
    chatGptSessionReady:true,chatGptRequestsSinceSetup:0,chatGptConversationAnchor:"",
    cachedVisualSignature:"",cachedVisualPath:"",
    currentPackage:()=>pkg,packageName:p=>query({pkg:p}),className:c=>query({cls:c}),classNameMatches:c=>query({clsRe:c}),
    textMatches:t=>query({text:t}),descMatches:d=>query({desc:d}),
    sleep:ms=>{now+=ms;if(onSleep)onSleep(ms);},click:(x,y)=>{taps.push([x,y]);if(onTap)onTap(x,y);return true;},
    back:()=>{},context:{},android:{graphics:{Rect:function(...args){return rect(...args);}},media:{MediaScannerConnection:{scanFile:()=>{}}}},
    captureScreen:()=>{captures++;return imageFixture||makeImage();},
    images:{pixel:(img,x,y)=>img.pixel(x,y),clip:(img,l,t,w,h)=>makeImage(w,h,(x,y)=>img.pixel(x+l,y+t)),
        save:(img,path)=>savedFiles.set(path,img)},
    ocr:{mode:"mlkit",detect:()=>ocrOutput},
    files:{exists:path=>savedFiles.has(path),ensureDir:()=>{},listDir:()=>[],remove:()=>{},append:()=>{}},
    java:{io:{File:function(path){return {length:()=>savedFiles.has(path)?128:0};}}},
    app:{launchPackage:p=>{pkg=p;}},waitForPackage:()=>{},ui:{run:()=>{}},
    memoryStore:{put:()=>{}},toast:()=>{}
});
vm.runInContext(source.match(/var VERSION =[^;]+;/)[0]+"\n"+source.match(/var CFG = \{[\s\S]*?\n\};/)[0],ctx);
for(const fn of source.matchAll(/^function [A-Za-z0-9_]+\([^]*?^\}/gm))vm.runInContext(fn[0],ctx);
const original={};for(const key of Object.keys(ctx))if(typeof ctx[key]==="function")original[key]=ctx[key];
let count=0;
function test(name,body){
    now=0;nodes=[];pkg="com.tencent.mobileqq";taps=[];onTap=null;onSleep=null;captures=0;logs=[];
    ocrOutput=[];imageFixture=null;savedFiles.clear();
    for(const [key,value]of Object.entries(original))ctx[key]=value;
    ctx.running=true;ctx.state={lastBotText:"",lastWasInterjection:false,recentTurns:[]};
    ctx.chatGptSessionReady=true;ctx.chatGptRequestsSinceSetup=0;ctx.chatGptConversationAnchor="";
    ctx.cachedVisualSignature="";ctx.cachedVisualPath="";
    ctx.logLine=s=>logs.push(s);ctx.setStatus=s=>logs.push(s);ctx.dismissQqKeyboard=()=>false;
    ctx.CFG.chatGptConversationTitle="";
    try{body();count++;console.log("PASS "+name);}catch(e){console.error("FAIL "+name);throw e;}
}
function makeImage(w=720,h=1600,pixel=()=>0xeeeeee){return {getWidth:()=>w,getHeight:()=>h,pixel,recycle:()=>{}};}
function sceneEmoji(x=180,y=1250){
    return makeImage(720,1600,(px,py)=>{
        const dx=px-x,dy=py-y;
        if(dx*dx+dy*dy>21*21)return 0xeeeeee;
        if((Math.abs(dx-7)<3||Math.abs(dx+7)<3)&&Math.abs(dy+5)<3)return 0x101010;
        if(dy>7&&Math.abs(dx)<12)return 0xa33828;
        if(dx<-13&&dy>0)return 0x29b8ea;
        return dx>4?0xffca35:0xffe271;
    });
}
function gptInput(){return input("",rect(100,1150,620,1320),{pkg:"com.openai.chatgpt"});}
function gptReply(s){return node(s,rect(40,800,680,940),{pkg:"com.openai.chatgpt"});}

test("focus is centered and reacquires a moving keyboard input",()=>{
    const old=input("",rect(90,1450,590,1540)),fresh=input();nodes=[old];
    onTap=()=>{nodes=[];};onSleep=()=>{if(now>=360)nodes=[fresh];};
    assert.equal(ctx.focusQqTextInput(),fresh);assert.deepEqual(taps,[[360,1495]]);assert.ok(now>=720);
});
test("voice toggle remains untouched during normal text input",()=>{
    nodes=[input()];assert.equal(ctx.ensureQqTextMode(),true);assert.equal(taps.length,0);
});
test("confirmed hold-to-talk toolbar restores keyboard",()=>{
    nodes=[node("按住说话",rect(100,1450,600,1540)),node("",rect(15,1460,75,1530),{desc:"切换到文字输入"})];
    onTap=()=>{nodes=[input()];};assert.equal(ctx.ensureQqTextMode(),true);assert.deepEqual(taps,[[45,1495]]);
});
test("multiline composer accepts bottom-aligned send labels",()=>{
    const edit=input("多行",rect(90,660,590,960));nodes=[edit,node("发送",rect(620,895,710,955))];
    assert.equal(ctx.clickQqSendButton(edit),true);assert.deepEqual(taps,[[665,925]]);
});
test("no send tap on unrelated chat text, voice or plus",()=>{
    const edit=input();nodes=[edit,node("发送",rect(620,600,710,670)),node("发送图片看看",rect(620,850,710,940)),
        node("语音",rect(620,850,710,940)),node("加号",rect(620,850,710,940))];
    assert.equal(ctx.clickQqSendButton(edit),false);assert.equal(taps.length,0);
});
test("send waits for a delayed button and confirms input clearing",()=>{
    const edit=input();nodes=[edit];let sent=0;
    onSleep=()=>{if(now>1300&&nodes.length===1)nodes.push(node("发 送",rect(620,850,710,940)));};
    onTap=(x)=>{if(x>620){sent++;edit.setText("");}};
    assert.equal(ctx.sendQqText("测试"),true);assert.equal(sent,1);assert.ok(now>1300);
});
test("send reacquires button after keyboard dismiss recovery",()=>{
    const edit=input();nodes=[edit];let dismiss=0;
    ctx.dismissQqKeyboard=()=>{dismiss++;nodes=[edit,node("发送",rect(620,850,710,940))];return true;};
    onTap=x=>{if(x>620)edit.setText("");};
    assert.equal(ctx.sendQqText("恢复"),true);assert.ok(dismiss>=1);
});
test("missing send label skips the batch and clears only its draft",()=>{
    const edit=input();nodes=[edit];assert.equal(ctx.sendQqText("待发送"),false);
    assert.equal(edit.text(),"");assert.deepEqual(taps,[[360,895]]);assert.ok(logs.some(s=>s.includes("发送前未找到按钮")));
});
test("unrelated existing draft is preserved",()=>{
    const edit=input("用户草稿");nodes=[edit];
    assert.throws(()=>ctx.sendQqText("机器人消息"),/其他草稿/);assert.equal(edit.text(),"用户草稿");
});
test("failed write does not tap send",()=>{
    const edit=input("",undefined,{failWrite:true});nodes=[edit,node("发送",rect(620,850,710,940))];
    assert.equal(ctx.sendQqText("测试"),false);assert.equal(taps.filter(t=>t[0]>620).length,0);
});
test("uncertain click is never retried",()=>{
    const edit=input();nodes=[edit,node("发送",rect(620,850,710,940))];
    assert.throws(()=>ctx.sendQqText("测试"),/发送状态未确认/);assert.equal(taps.filter(t=>t[0]>620).length,1);
});
test("toolbar OCR keeps send labels but ordinary chat OCR filters them",()=>{
    const data=[{text:"发送",bounds:{left:10,top:10,right:50,bottom:35}}];
    assert.equal(ctx.normalizeOcrDetailed(data,{},true).length,1);assert.equal(ctx.normalizeOcrDetailed(data,{}).length,0);
});
test("OCR fallback clicks only a confirmed label outside composer",()=>{
    const edit=input("测试");nodes=[edit];ocrOutput=[{text:"发送",bounds:{left:45,top:15,right:95,bottom:50}}];
    assert.equal(ctx.clickQqSendByOcr(edit,"测试"),true);assert.equal(taps.length,1);assert.ok(taps[0][0]>620);
});
test("OCR fallback rejects a composer that moved after screenshot",()=>{
    const old=input("测试");nodes=[input("测试",rect(90,1100,590,1190))];
    ocrOutput=[{text:"发送",bounds:{left:45,top:15,right:95,bottom:50}}];
    assert.equal(ctx.clickQqSendByOcr(old,"测试"),false);assert.equal(taps.length,0);
});
test("emoji detector preserves modern sequences and avoids ASCII words",()=>{
    for(const s of ["😂","👍🏽","👩‍💻","🇨🇳","1️⃣","❤️","🫠","[捂脸]","文字😂"])assert.equal(ctx.containsEmojiText(s),true,s);
    for(const s of ["NR测试","M","普通文字","[图片]","test123"])assert.equal(ctx.containsEmojiText(s),false,s);
});
test("raw emoji text is read only from chat region, not avatars or toolbar",()=>{
    nodes=[input(),node("😂",rect(150,650,190,690)),node("👍",rect(10,650,50,690)),
        node("😀",rect(150,1450,190,1490)),node("👀",rect(150,15,190,55))];
    const found=ctx.readQqEmojiItems({width:720,top:168,bottom:820,scaleY:1});
    assert.equal(found.length,1);assert.equal(found[0].text,"😂");
});
test("native parent duplicates collapse while separate repeated emoji remain",()=>{
    nodes=[input(),node("😂",rect(140,600,220,690)),node("😂",rect(150,620,190,660)),node("😂",rect(150,730,190,770))];
    const found=ctx.readQqEmojiItems({width:720,top:168,bottom:820,scaleY:1});assert.equal(found.length,2);
});
test("native emoji replaces OCR within the same bubble and keeps nickname",()=>{
    const ocr=[{text:"请填写你的QQ昵称",x:150,y:600,right:270,bottom:625},{text:"哈口",x:160,y:650,right:210,bottom:680}];
    const native=[{text:"哈😂",x:150,y:640,right:230,bottom:690}];
    const out=ctx.mergeQqEmojiItems(ocr,native);assert.deepEqual(Array.from(out,x=>x.text),["请填写你的QQ昵称","哈😂"]);
});
test("small colorful emoji passes independent candidate scan",()=>{
    const result=ctx.findQqSmallEmojiCandidates(sceneEmoji(),{top:168,bottom:1400},null);
    assert.ok(result.length>0);assert.ok(result.some(b=>Math.abs(b.centerX()-180)<10&&Math.abs(b.centerY()-1250)<10));
});
test("avatar position and large flat colored background are not small emoji",()=>{
    assert.equal(ctx.findQqSmallEmojiCandidates(sceneEmoji(35,1250),{top:168,bottom:1400},null).length,0);
    assert.equal(ctx.findQqSmallEmojiCandidates(makeImage(720,1600,()=>0x2299ff),{top:168,bottom:1400},null).length,0);
});
test("large image content is not scanned again as small emoji",()=>{
    assert.equal(ctx.findQqSmallEmojiCandidates(sceneEmoji(),{top:168,bottom:1400},rect(120,1190,250,1310)).length,0);
});
test("already readable native emoji does not require duplicate screenshot",()=>{
    const out=ctx.chooseQqVisual(sceneEmoji(),{top:168,bottom:1400},null,[{x:150,y:1220,right:210,bottom:1280,text:"😂"}]);
    assert.equal(out.bounds,null);assert.equal(out.signature,"");
});
test("changed emoji pixels change fingerprint even without OCR text",()=>{
    const one=ctx.chooseQqVisual(sceneEmoji(),{top:168,bottom:1400},null,[]);
    const two=ctx.chooseQqVisual(makeImage(720,1600,(x,y)=>{const c=sceneEmoji().pixel(x,y);return c===0xffca35?0xea6535:c;}),{top:168,bottom:1400},null,[]);
    assert.ok(one.signature);assert.notEqual(one.signature,two.signature);
});
test("pure native emoji makes an otherwise empty OCR frame valid",()=>{
    nodes=[input("",rect(90,1450,590,1540)),node("😂",rect(160,1250,200,1290))];
    const shot=ctx.readQqScreen();assert.equal(shot.valid,true);assert.deepEqual(Array.from(shot.lines),["😂"]);assert.equal(shot.nativeEmojiCount,1);
});
test("visual screenshot uses exactly the OCR capture, not a later frame",()=>{
    nodes=[input("",rect(90,1450,590,1540))];imageFixture=sceneEmoji();
    const shot=ctx.readQqScreen();assert.ok(shot.visualPath);assert.equal(captures,1);assert.ok(savedFiles.has(shot.visualPath));
});
test("NR variants still work with two-space version suffix",()=>{
    for(const s of ["NR测试","nr 测试","N R测试","ＮＲ测试"])assert.equal(ctx.startsWithNoReplyMarker(s),true);
    for(const s of ["M测试","////测试","正常NR"])assert.equal(ctx.startsWithNoReplyMarker(s),false);
    for(const s of ["测试","测试（v0.6.5）","测试  v0.6.5"])assert.equal(ctx.appendVersion(s),"测试  v0.6.6");
    assert.equal(ctx.appendVersion("长".repeat(400)).length,350);
});
test("NR requires owner identity and cannot suppress a newer visual",()=>{
    const shot={lines:["请填写你的QQ昵称","NR免回"],ocrItems:[{text:"请填写你的QQ昵称",x:150,y:1100,bottom:1125},{text:"NR免回",x:150,y:1150,bottom:1180}]};
    assert.equal(ctx.isLatestOwnerNoReplyMessage(shot),true);
    assert.equal(ctx.isLatestOwnerNoReplyMessage({...shot,visualBottom:1300}),false);
    assert.equal(ctx.isLatestOwnerNoReplyMessage({lines:["别人","NR免回"],ocrItems:[]}),false);
});
test("all prompt routes say fewer emoji and preserve reply protocol",()=>{
    for(const text of [ctx.buildSetupPrompt("QQBOT_SETUP1"),ctx.buildTurnPrompt(["hi"],"QQBOT_1"),ctx.buildImageTurnPrompt(["hi"],"QQBOT_1")]) {
        assert.ok(text.includes("少用emoji"));assert.ok(text.includes("不要习惯性在句尾加表情"));assert.ok(text.includes("NO_REPLY"));
    }
});
test("project new-chat page cannot receive prompts",()=>{
    pkg="com.openai.chatgpt";const edit=gptInput();nodes=[edit,node("新聊天",rect(100,300,600,350),{pkg})];
    assert.throws(()=>ctx.sendChatGptPrompt("测试"),/ChatGPT页面未确认/);assert.equal(edit.text(),"");assert.equal(taps.length,0);
});
test("an existing protocol reply authorizes the same conversation",()=>{
    pkg="com.openai.chatgpt";nodes=[gptInput(),gptReply("QQBOT_SETUPABC|READY")];assert.equal(ctx.hasBotConversationEvidence(),true);
    ctx.chatGptConversationAnchor="QQBOT_SETUPABC";assert.equal(ctx.hasBotConversationEvidence(),true);
    ctx.chatGptConversationAnchor="QQBOT_OTHER";assert.equal(ctx.hasBotConversationEvidence(),false);
});
test("a protocol string in the composer is not conversation evidence",()=>{
    pkg="com.openai.chatgpt";const edit=gptInput();edit.setText("QQBOT_SETUPABC|READY");nodes=[edit];assert.equal(ctx.hasBotConversationEvidence(),false);
});
test("unknown project list does not trigger a new chat or guessed title",()=>{
    pkg="com.openai.chatgpt";nodes=[gptInput(),node("回复",rect(50,500,500,560),{pkg})];
    assert.throws(()=>ctx.openChatGptForBot(),/ChatGPT页面未确认/);assert.equal(taps.length,0);
});
test("attachment evidence recognizes remove control in description",()=>{
    pkg="com.openai.chatgpt";nodes=[gptInput(),node("",rect(580,1050,620,1090),{pkg,desc:"Remove attachment"})];
    assert.equal(ctx.hasChatGptDraftAttachment("QQBOT_visual_1.jpg"),true);
});
test("exact filename search ignores search text field and arbitrary images",()=>{
    pkg="com.android.documentsui";
    nodes=[input("QQBOT_visual_123.jpg",rect(50,50,600,110),{pkg}),node("",rect(20,400,700,700),{pkg,cls:"android.widget.ImageView"})];
    assert.equal(ctx.selectExactScreenshotFile("QQBOT_visual_123.jpg"),false);assert.equal(taps.length,0);
});
test("exact screenshot file is selected, other photo is never selected",()=>{
    pkg="com.android.documentsui";nodes=[node("private.jpg",rect(50,400,600,470),{pkg}),node("QQBOT_visual_123.jpg",rect(50,500,600,570),{pkg})];
    assert.equal(ctx.selectExactScreenshotFile("QQBOT_visual_123.jpg"),true);assert.deepEqual(taps,[[325,535]]);
});
test("image request launches and checks ChatGPT before attachment",()=>{
    let actions=[];ctx.openChatGptForBot=()=>actions.push("open");ctx.sendChatGptImagePrompt=()=>actions.push("attach");ctx.waitForChatGptDecision=()=>({type:"none"});
    ctx.askChatGpt(["图"],"current.jpg");assert.deepEqual(actions,["open","attach"]);
});
test("failed visual capture is not sent as if GPT could see emoji",()=>{
    ctx.isLatestOwnerNoReplyMessage=()=>false;let called=0;ctx.askChatGpt=()=>called++;
    ctx.handleBatch({lines:["[小表情]"],visualPath:null},true);assert.equal(called,0);
});
test("pre-send QQ failure does not update sent history",()=>{
    ctx.isLatestOwnerNoReplyMessage=()=>false;ctx.askChatGpt=()=>({type:"reply",text:"回复"});ctx.returnToQq=()=>{};
    ctx.sendQqText=()=>false;ctx.rememberTurn=()=>{throw Error("must not record unsent message");};
    ctx.handleBatch({lines:["hi"]},false);assert.equal(ctx.state.lastBotText,"");
});
test("expanded GPT composer remains discoverable for long setup prompt",()=>{
    pkg="com.openai.chatgpt";const edit=input("long",rect(70,190,640,960),{pkg});nodes=[edit];
    assert.equal(ctx.findChatGptEditable(),edit);
});
test("ambiguous false from tap does not cause a second send attempt",()=>{
    const edit=input();nodes=[edit,node("发送",rect(620,850,710,940))];
    ctx.click=(x,y)=>{taps.push([x,y]);return x<620;};
    assert.throws(()=>ctx.sendQqText("测试"),/发送状态未确认/);assert.equal(taps.filter(t=>t[0]>620).length,1);
});
test("same visual with new sender context gets a new current screenshot",()=>{
    const img=sceneEmoji(),b=rect(150,1220,210,1280),region={top:168,bottom:1400};
    const first=ctx.saveQqVisualSnapshot(img,b,region,"same-emoji","sender-a");now+=1000;
    assert.equal(ctx.saveQqVisualSnapshot(img,b,region,"same-emoji","sender-a"),first);
    const next=ctx.saveQqVisualSnapshot(img,b,region,"same-emoji","sender-b");assert.notEqual(first,next);
});
console.log("Syntax and "+count+" behavior checks passed.");
