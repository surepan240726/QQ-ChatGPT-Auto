# QQ × ChatGPT 自动聊天 v0.4.15

改为单聊天方案；优先处理最新消息；加入有限轮次本地上下文、消息版本后缀及早期人设。

> 这是历史版本，仅供回溯；日常使用请下载 v0.6.10。

## 运行环境

- Android 或兼容 Android 应用的系统
- AutoJs6 6.7+
- Android 版 QQ（包名 `com.tencent.mobileqq`）
- Android 版 ChatGPT（包名 `com.openai.chatgpt`）
- 已登录的 ChatGPT 账号和可用网络
- AutoJs6 无障碍、截图/录屏及文件访问权限

不需要 OpenAI API Key、QQ 官方机器人接口、服务器或电脑常驻。

## 使用前

1. 编辑脚本中的 `ownerNickname`，填写自己的 QQ 昵称
2. 停止其他版本，避免多个脚本同时运行
3. QQ 停在目标聊天，ChatGPT 停在机器人专用对话底部
4. 先运行“测试 OCR”，确认内容和聊天名称正确
5. 再开始监听；异常时按音量上键紧急停止

## 说明

这是非官方的界面自动化脚本，与腾讯、QQ、OpenAI 或 ChatGPT 无隶属关系。QQ 或 ChatGPT 界面更新可能导致失效；OCR 也可能误识别，请自行评估账号和自动发送风险。

