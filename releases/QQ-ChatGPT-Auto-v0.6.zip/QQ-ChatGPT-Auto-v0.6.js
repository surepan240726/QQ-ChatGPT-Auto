"ui";

/* QQ × ChatGPT 自动群聊 v0.6 - AutoJs6 6.7+
 * 单群版：最新消息优先、聊天区动态OCR；v0.4.21移除发送前二次OCR复核。
 * v0.6：取消本地主动插话概率；每次新群聊内容都交给GPT，普通公开话题由GPT按约60%插话；新增QQ图片/静态表情视觉附件实验通道。
 * 主动插话目标约60%：不在本地抽签，每次新内容都交给GPT自行决定；不增加多群独立配置。
 * 尚未在用户手机上实机验证，请先测试OCR后再监听。
 */
var VERSION = "v0.6";
var CFG = {
    qqPackage: "com.tencent.mobileqq",
    chatgptPackage: "com.openai.chatgpt",
    quietMs: 450,
scanIntervalMs: 200,
    chatgptTimeoutMs: 30000,
    keepAwakeLeaseMs: 12 * 60 * 60 * 1000,   // 单次保持暗屏常亮12小时
    keepAwakeRefreshMs: 6 * 60 * 60 * 1000, // 每6小时续一次
    appSwitchWaitMs: 1700,
    chatTopRatio: 0.105,
    chatInputGapPx: 16,      // 聊天文字最下缘与QQ输入框顶部的保护距离
    minChatAreaRatio: 0.18, // 聊天区域太小则跳过，不读键盘
    interjectChance: 0.60, // 仅作为提示给GPT，不在本地抽签
    maxOcrLines: 30,
    recentTurnsLimit: 4,
    setupRefreshEvery: 30,     // 每30次实际聊天请求刷新一次完整规则
    botAliases: "GPT-6A,GPT,ChatGPT",
    ownerNickname: "请填写你的QQ昵称", // 这是QQ群昵称，不是QQ号；只用于聊天身份识别
    visualCacheDir: "/sdcard/AutoJs6/qq_gpt_cache/",
    visualCachePath: "/sdcard/AutoJs6/qq_gpt_cache/latest_visual.png",
    logFile: "/sdcard/AutoJs6/qq_chatgpt_v4.log"
};

var running = false;
var nextKeepAwakeRefreshAt = 0;
var worker = null;
var captureGranted = false;
var chatGptSessionReady = false;
var chatGptRequestsSinceSetup = 0;
// 只有单群的一份持久状态。历史存本机 AutoJs6，不传到任何额外服务。
var memoryStore = storages.create("qq_chatgpt_single_v0415");
var state = { lastBotText: "", lastWasInterjection: false, recentTurns: [] };
loadLocalState();

ui.layout(
    <vertical padding="18">
        <text text="QQ × ChatGPT 自动群聊 v0.6" textSize="22sp" textStyle="bold" />
        <text marginTop="10" text="运行前让 QQ 停在目标群、ChatGPT 停在专用对话。需要无障碍和截图权限；OCR 使用 AutoJs6 自带的 ML Kit。" textSize="14sp" />
        <text id="status" marginTop="14" text="状态：未运行" textColor="#777777" />
        <button id="testOcr" marginTop="16" text="第一步：测试 OCR" />
        <button id="start" text="第二步：开始监听" />
        <button id="stop" text="停止" enabled="false" />
        <text marginTop="12" text="单群版；文字OCR + 图片视觉附件；每条群消息追加版本号。音量上键可紧急停止。" textColor="#D32F2F" />
    </vertical>
);

ui.testOcr.click(() => threads.start(testOcr));
ui.start.click(() => startBot());
ui.stop.click(() => stopBot("已手动停止"));

events.observeKey();
events.onKeyDown("volume_up", () => stopBot("已用音量上键停止"));

function setStatus(s) {
    ui.run(() => ui.status.setText("状态：" + s));
    logLine(s);
}

function setButtons(isRunning) {
    ui.run(() => {
        ui.start.setEnabled(!isRunning);
        ui.stop.setEnabled(isRunning);
        ui.testOcr.setEnabled(!isRunning);
    });
}

function getCapturePermission() {
    if (captureGranted) return true;
    captureGranted = requestScreenCapture(false);
    return captureGranted;
}

function enableKeepAwake() {
    try {
        device.keepScreenDim(CFG.keepAwakeLeaseMs);
        nextKeepAwakeRefreshAt = Date.now() + CFG.keepAwakeRefreshMs;
        logLine("已开启暗屏常亮");
    } catch (e) {
        logLine("开启暗屏常亮失败：" + e);
    }
}

function refreshKeepAwakeIfNeeded() {
    if (!running || Date.now() < nextKeepAwakeRefreshAt) return;
    enableKeepAwake();
}

function disableKeepAwake() {
    try {
        device.cancelKeepingAwake();
        nextKeepAwakeRefreshAt = 0;
        logLine("已取消暗屏常亮");
    } catch (e) {
        logLine("取消暗屏常亮失败：" + e);
    }
}

function startBot() {
    if (running) return;
    if (!auto.service) {
        toast("请先开启 AutoJs6 无障碍服务");
        app.startActivity({ action: "android.settings.ACCESSIBILITY_SETTINGS" });
        return;
    }
    if (!getCapturePermission()) {
        toast("没有取得截图权限");
        return;
    }
    running = true;
    enableKeepAwake();
    setButtons(true);
    worker = threads.start(mainLoop);
}

function stopBot(reason) {
    running = false;
    chatGptSessionReady = false;
    chatGptRequestsSinceSetup = 0;
    disableKeepAwake();
    if (worker) {
        try { worker.interrupt(); } catch (_) {}
        worker = null;
    }
    setButtons(false);
    setStatus(reason || "已停止");
}

function mainLoop() {
    try {
        ensureOcrReady();

        // 启动时先在专用ChatGPT对话里发送一次完整规则。
        // 初始化失败不让整个机器人死亡；下一条真正需要GPT的消息会再次尝试初始化。
        try {
            initializeChatGptSession();
        } catch (setupError) {
            chatGptSessionReady = false;
            logLine("启动规则初始化失败：" + setupError);
        }

        openQqAndCheck();
        setStatus(chatGptSessionReady ?
            "规则已初始化，定位到最新消息，等待新发言" :
            "规则初始化暂未成功，已回QQ监听；需要时会重新初始化");
        ensureQqAtBottom();
        var observedSignature = null;
        var processedSignature = null;
        var processedVisualSignature = "";
        var lastChangeAt = Date.now();
        while (running) {
            refreshKeepAwakeIfNeeded();
            if (!isQqPageActive()) {
                setStatus("QQ 群聊未显示，暂停识别");
                sleep(700);
                continue;
            }
            dismissQqKeyboard();
            if (!isQqPageActive()) { sleep(400); continue; }
            // 只在明确识别到“回到底部/新消息”等按钮时点击。
            // 禁止任何 swipe/自动滑动，避免误触群聊界面。
            var moved = ensureQqAtBottom();
            if (moved) sleep(280);
            var shot = readQqScreen();
            if (!shot.valid || !shot.lines.length) {
                setStatus("未能确认聊天区域，等待下一次识别");
                sleep(700);
                continue;
            }
            // 初次读到群聊仅作为基线，不能把历史消息当作新消息。
            if (observedSignature === null) {
                observedSignature = shot.chatSignature;
                processedSignature = shot.chatSignature;
                processedVisualSignature = shot.visualSignature || "";
                lastChangeAt = Date.now();
                setStatus("监听中：已对齐最新消息");
            } else if (shot.chatSignature !== observedSignature) {
                var now = Date.now();
                observedSignature = shot.chatSignature;
                lastChangeAt = now;
                setStatus("本地检测到聊天内容变化，等待短暂稳定");
            } else if (shot.chatSignature !== processedSignature) {
                var now2 = Date.now();
                var quietEnough = now2 - lastChangeAt >= CFG.quietMs;
                if (quietEnough) {
                    // 标记的只是这次交给模型的快照，不是切回QQ时出现的新消息。
                    var visualChanged = !!shot.visualSignature &&
                        shot.visualSignature !== processedVisualSignature;
                    processedSignature = shot.chatSignature;
                    processedVisualSignature = shot.visualSignature || "";
                    handleBatch(shot, visualChanged);
                    if (!running) break;
                    // 如果切应用期间有新消息，绝不把新画面直接当作已处理。
                    var after = readQqScreen();
                    if (after.valid && after.lines.length &&
                        after.chatSignature !== observedSignature) {
                        observedSignature = after.chatSignature;
                        lastChangeAt = Date.now();
                        setStatus("本地检测到新的聊天内容，进入下一轮处理");
                    }
                }
            }
            sleep(CFG.scanIntervalMs);
        }
    } catch (e) {
        logLine("FATAL: " + e + "\n" + (e.stack || ""));
        toast("脚本停止：" + e);
        stopBot("发生错误，请查看日志");
    }
}

function latestMeaningfulIndex(lines) {
    for (var i = lines.length - 1; i >= 0; i--) {
        var s = String(lines[i] || "").trim();
        if (!s || isTransientQqLine(s)) continue;
        return i;
    }
    return -1;
}

// 只在“请填写你的QQ昵称 -> //正文”的归属足够明确，而且这条确实是当前最末消息时本地跳过。
// 避免仅因为屏幕其他位置出现//就误伤别人的发言。
function isLatestOwnerSlashMessage(lines) {
    var last = latestMeaningfulIndex(lines);
    if (last < 0) return false;

    var owner = String(CFG.ownerNickname || "").trim();
    var lastText = String(lines[last] || "").trim();

    // 昵称和正文被OCR到同一行：请填写你的QQ昵称: //xxx / 请填写你的QQ昵称 //xxx
    if (lastText.indexOf(owner) === 0) {
        var rest = lastText.slice(owner.length).replace(/^[\s:：-]+/, "");
        if (/^\/\//.test(rest)) return true;
    }

    // 昵称一行、正文紧接下一行。只接受“//正文”就是最后一条有效OCR文本。
    if (/^\/\//.test(lastText)) {
        for (var i = last - 1; i >= 0 && i >= last - 3; i--) {
            var prev = String(lines[i] || "").trim();
            if (!prev || isTransientQqLine(prev)) continue;
            return prev === owner;
        }
    }
    return false;
}

// 本地只判断非常明确的点名，避免把“我刚问了GPT”这种普通聊天误当成在叫机器人。
// 明确点名时100%请求GPT，不走75%主动插话抽签。
function handleBatch(shot, visualChanged) {
    // “//”是使用者明确的免回复指令：仍在本地硬过滤，不消耗GPT请求。
    if (isLatestOwnerSlashMessage(shot.lines)) {
        setStatus("检测到请填写你的QQ昵称的//免回复消息，本轮本地跳过");
        logLine("本地免回复：请填写你的QQ昵称 的最新消息以 // 开头");
        return;
    }

    var visualPath = null;

    // 只有“最近的大图/静态表情内容”相对上次确实变化时才截视觉附件。
    // 普通纯文字消息继续走轻量文字通道。
    if (visualChanged) {
        try {
            visualPath = captureLatestQqVisualToFile();
            if (visualPath) logLine("已保存本轮QQ视觉附件：" + visualPath);
        } catch (visualError) {
            logLine("视觉附件获取失败，退回OCR文字：" + visualError);
            visualPath = null;
        }
    }

    setStatus(visualPath ?
        "发现新的图片/静态表情，正在交给ChatGPT看图判断" :
        "ChatGPT 正在判断本轮是否回复/插话");

    var result;
    try {
        result = askChatGpt(shot.lines, visualPath);
    } catch (readError) {
        if (!running) return;
        var errText = String(readError || "");
        logLine("读取失败，先尝试返回QQ：" + errText);
        try { returnToQq(); }
        catch (jumpError) { logLine("失败后的返回QQ也失败：" + jumpError); }

        // 超时或规则初始化异常：本轮作废，不重试这一批消息。
        if (errText.indexOf("等待 ChatGPT 回复超时") >= 0 ||
            errText.indexOf("ChatGPT规则初始化超时") >= 0 ||
            errText.indexOf("ChatGPT图片分享失败") >= 0) {
            chatGptSessionReady = false;
            setStatus("GPT/规则30秒超时或图片通道失败，本轮放弃");
            return;
        }
        throw readError;
    }

    if (!running) return;
    returnToQq();

    if (!result || result.type === "none") {
        state.lastWasInterjection = false;
        setStatus("GPT 本轮选择不插话，继续监听");
        return;
    }

    // GPT 已明确返回 REPLY/INTERJECT 后直接发送，不再二次OCR复核。
    var textToSend = appendVersion(result.text);
    if (!textToSend || !running) return;
    sendQqText(textToSend);
    state.lastBotText = textToSend;
    state.lastWasInterjection = result.type === "interject";
    rememberTurn(shot.lines, textToSend);
    setStatus("已发送（" + VERSION + "），继续监听");
}

function loadLocalState() {
    try {
        var saved = memoryStore.get("history", null);
        if (!saved || typeof saved !== "object") return;
        state.lastBotText = String(saved.lastBotText || "").slice(-380);
        state.lastWasInterjection = saved.lastWasInterjection === true;
        state.recentTurns = Array.isArray(saved.recentTurns) ?
            saved.recentTurns.slice(-CFG.recentTurnsLimit) : [];
    } catch (e) { logLine("加载本地上下文失败：" + e); }
}

function rememberTurn(lines, reply) {
    state.recentTurns.push({
        context: lines.slice(-7).join(" / ").slice(-380),
        bot: String(reply || "").slice(0, 360)
    });
    state.recentTurns = state.recentTurns.slice(-CFG.recentTurnsLimit);
    try { memoryStore.put("history", state); }
    catch (e) { logLine("保存本地上下文失败：" + e); }
}

function appendVersion(raw) {
    var s = String(raw || "").replace(/\s+/g, " ").trim();
    if (!s) return "";
    // 防止GPT自己生成版本号后脚本又附加一次；以实际脚本版本为准。
    s = s.replace(/\s*[（(]\s*v\d+\.\d+\.\d+\s*[）)]\s*$/i, "").trim();
    var suffix = "（" + VERSION + "）";
    if (s.length + suffix.length > 350) s = s.slice(0, 350 - suffix.length);
    return s + suffix;
}

function buildSetupPrompt(setupToken) {
    return [
        "这是QQ机器人GPT-6A的会话初始化规则。后续每一轮我会只发送精简的本轮OCR，不再重复这些长期规则。请持续遵守，直到我再次发送初始化规则。",
        "",
        "身份：",
        "1. 你在QQ群里作为普通群友聊天，群昵称是GPT-6A；别人也可能称呼你GPT或ChatGPT。",
        "2. 机器人的使用者在本群显示昵称是：" + CFG.ownerNickname + "。这是QQ群昵称，不是QQ号，也不是你的名字。只有OCR明确显示该昵称是某条消息发送者时，才认定是使用者。",
        "3. 使用者也只是普通群友；他和别人聊天时不要因为他是使用者就强行插嘴。",
        "4. 如果最新消息明确属于" + CFG.ownerNickname + "且正文以//开头，这是免回复标记。手机本地会优先过滤；如果极少数情况下仍传到你这里，不要生成群聊回复。",
        "",
        "人设：",
        "5. 参考群友常说的“蓝色大肥鱼/鲸鱼娘”二创气质：聪明、贪吃、爱面子、调皮，偶尔嘴硬和顶嘴，但整体友善、好相处。",
        "6. 你始终是GPT-6A，只是在用鱼系人设伪装/玩梗；你不是DeepSeek，也不要冒充任何官方角色。",
        "7. 群里单独出现“鱼”“大肥鱼”“鲸鱼”等称呼时，优先理解为在叫群里的其他DeepSeek/DS角色或机器人。只有明确点名GPT-6A/GPT/ChatGPT，或上下文明显承接你自己的话时，才把这些称呼理解为在叫你。",
        "8. 可以偶尔拿吃饭、白饭、Token当口粮开玩笑，但不要固定重复“本鲸”“哼”“笨蛋”等口癖，不要句句卖萌。正经问题就认真回答。",
        "9. 语气友善，可以损一点、皮一点，但尽量吐槽事情而不是攻击人；不要捏造事实。",
        "",
        "判断规则：",
        "10. 每轮严格以最新一条【本轮OCR】判断当前发生了什么；以前的OCR只是历史上下文，绝不能当成本轮新消息重新回复。",
        "11. 每次检测到新的群聊内容都会交给你判断。若最新内容明确点名GPT-6A/GPT/ChatGPT或明显承接你的话，应使用REPLY直接回应；否则对于能自然参与的普通公开聊天，目标是大约60%的轮次使用INTERJECT主动加入、约40%的轮次使用NO_REPLY保持沉默。概率由你在每轮自行判断，不在手机本地抽签。",
        "12. 不要回复你自己刚发的话、不要自言自语。有人明确只点名其他人求助且不适合旁人插话时不要代答。",
        "13. OCR可能有错字、时间、等级、按钮等杂项；昵称与正文也可能被拆成相邻行。无法确定发送者时不要硬猜。",
        "14. 回复像真实群友，通常一两句，具体自然，避免客服腔和说教。",
        "15. 不要在回复正文中添加版本号，发送脚本会自动追加。",
        "",
        "后续每轮会给你一个唯一QQBOT请求编号。每轮都由你决定直接回复、主动插话或沉默。不要Markdown、不要解释：",
        "严格只输出以下三种之一：",
        "QQBOT_xxx|NO_REPLY",
        "QQBOT_xxx|REPLY:要发送的文字",
        "QQBOT_xxx|INTERJECT:主动插嘴的文字",
        "",
        "如果已经理解并会持续遵守以上规则，本次只回复：",
        setupToken + "|READY"
    ].join("\n");
}

function buildTurnPrompt(lines, token) {
    return [
        "按已初始化的QQBOT规则处理本轮。",
        "请求：" + token,
        "本轮每次都由你判断：",
        "1. 明确点名GPT-6A/GPT/ChatGPT或明显在接你的话 -> REPLY。",
        "2. 普通公开聊天如果能自然参与 -> 以约60%的频率INTERJECT，约40%的频率NO_REPLY。",
        "3. 不要因为上一轮已经插话/沉默就机械补偿概率；结合当前语境自然决定。",
        "上一条GPT-6A发言：" + (state.lastBotText || "无"),
        "上一条是否主动插话：" + (state.lastWasInterjection ? "是" : "否"),
        "只把下面【本轮OCR】当作当前新画面；旧对话不要重新回应。",
        "",
        "本轮只允许输出：",
        token + "|NO_REPLY",
        token + "|REPLY:要发送的文字",
        token + "|INTERJECT:主动插嘴的文字",
        "",
        "【本轮OCR，从上到下，越后越接近最新消息】",
        lines.slice(-CFG.maxOcrLines).join("\n")
    ].join("\n");
}

function buildImageTurnPrompt(lines, token) {
    return [
        "你现在作为QQ群普通群友GPT-6A处理一轮群聊。附件图片是手机刚从QQ聊天区截出的最新大图/静态表情区域，请直接观察图片内容，并结合OCR判断。",
        "你始终是GPT-6A，只是套用聪明、贪吃、爱面子、调皮但整体友善的“大肥鱼/鲸鱼娘”二创风格；你不是DeepSeek。",
        "别人单独说“鱼/大肥鱼/鲸鱼”时优先认为是在叫群里其他DS，除非明确点名GPT-6A/GPT/ChatGPT或明显承接你的话。",
        "机器人的使用者群昵称是请填写你的QQ昵称；如果明确是他发言且正文以//开头则不要回应。",
        "明确点名你 -> REPLY；普通公开聊天/图片梗图如果能自然参与 -> 约60% INTERJECT、约40% NO_REPLY。",
        "回复通常一两句，友善自然，不要捏造图片里看不到的细节，不要加版本号。",
        "",
        "请求：" + token,
        "上一条GPT-6A发言：" + (state.lastBotText || "无"),
        "",
        "只允许输出：",
        token + "|NO_REPLY",
        token + "|REPLY:要发送的文字",
        token + "|INTERJECT:主动插嘴的文字",
        "",
        "【本轮OCR】",
        lines.slice(-CFG.maxOcrLines).join("\n")
    ].join("\n");
}

function openChatGptForBot() {
    app.launchPackage(CFG.chatgptPackage);
    waitForPackage(CFG.chatgptPackage, 12000);
    sleep(CFG.appSwitchWaitMs);
}

function sendChatGptPrompt(prompt) {
    var input = findEditable();
    if (!input) throw new Error("找不到 ChatGPT 输入框");
    input.click();
    sleep(250);
    input.setText(prompt);
    sleep(350);
    if (!clickChatGptSend() && !clickSendButton(
        input,
        /发送|发送消息|发送提示|Send|Send message|Send prompt|提交|Submit/i,
        { xRatio: 0.895, yRatio: 0.615 }
    )) {
        throw new Error("找不到 ChatGPT 发送按钮");
    }
}

function sendChatGptImagePrompt(imagePath, prompt) {
    try {
        var Intent = android.content.Intent;
        var uri = app.getUriForFile(imagePath);
        var intent = new Intent(Intent.ACTION_SEND);
        intent.setType("image/png");
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.putExtra(Intent.EXTRA_TEXT, String(prompt));
        intent.setPackage(CFG.chatgptPackage);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    } catch (e) {
        throw new Error("ChatGPT图片分享失败：" + e);
    }

    waitForPackage(CFG.chatgptPackage, 12000);
    sleep(Math.max(CFG.appSwitchWaitMs, 2200));

    // 部分ChatGPT版本会把分享文字自动填入；没有填入时再手动写入。
    var input = findEditable();
    if (!input) throw new Error("ChatGPT图片分享失败：找不到输入框");
    var existing = String(input.text() || "").trim();
    if (existing.indexOf("QQBOT_") < 0) {
        input.click();
        sleep(200);
        input.setText(prompt);
        sleep(400);
    }

    if (!clickChatGptSend() && !clickSendButton(
        input,
        /发送|发送消息|发送提示|Send|Send message|Send prompt|提交|Submit/i,
        { xRatio: 0.895, yRatio: 0.615 }
    )) {
        throw new Error("ChatGPT图片分享失败：找不到发送按钮");
    }
}

function normalizeProtocolText(value) {
    return String(value || "")
        .replace(/^```\w*\s*|```$/g, "")
        .replace(/[\r\n\t]+/g, "")
        .replace(/\s+/g, " ")
        .trim();
}

function findSetupAck(setupToken) {
    var expected1 = setupToken + "|READY";
    var expected2 = setupToken + "｜READY";
    try {
        var nodes = packageName(CFG.chatgptPackage).find();
        for (var i = nodes.size() - 1; i >= 0; i--) {
            try {
                var n = nodes.get(i);
                if (!n || String(n.className()) === "android.widget.EditText") continue;
                var values = [String(n.text() || ""), String(n.desc() || "")];
                for (var j = 0; j < values.length; j++) {
                    var s = normalizeProtocolText(values[j]).replace(/\s+/g, "");
                    if (s === expected1 || s === expected2) return true;
                }
            } catch (_) {}
        }
    } catch (e) {
        logLine("枚举ChatGPT初始化确认失败：" + e);
    }
    return false;
}

function initializeChatGptSession() {
    var setupToken = "QQBOT_SETUP" + Date.now().toString(36).toUpperCase();
    openChatGptForBot();
    logLine(VERSION + " 发送完整规则初始化=" + setupToken);
    sendChatGptPrompt(buildSetupPrompt(setupToken));

    var deadline = Date.now() + CFG.chatgptTimeoutMs;
    while (running && Date.now() < deadline) {
        sleep(900);
        if (findSetupAck(setupToken)) {
            chatGptSessionReady = true;
            chatGptRequestsSinceSetup = 0;
            logLine("ChatGPT完整规则初始化成功");
            return true;
        }
    }

    // mainLoop启动早期running可能尚处于true；如果用户手动停止则直接返回。
    if (!running) return false;
    chatGptSessionReady = false;
    throw new Error("ChatGPT规则初始化超时");
}

function waitForChatGptDecision(token) {
    var deadline = Date.now() + CFG.chatgptTimeoutMs;
    var lastSignature = "", stableSince = 0;

    while (running && Date.now() < deadline) {
        sleep(900);
        var latest = findLatestProtocolNode(token);
        if (!latest) continue;
        logLine("匹配函数已返回=" + JSON.stringify(latest));

        if (latest.body !== "NO_REPLY") {
            if (latest.signature !== lastSignature) {
                lastSignature = latest.signature;
                stableSince = Date.now();
                continue;
            }
            if (Date.now() - stableSince < 3000) continue;
        }

        logLine("已枚举到新ChatGPT决策：" + latest.signature);
        return parseDecision(token + "|" + latest.body, token);
    }

    if (!running) return null;
    chatGptSessionReady = false;
    throw new Error("等待 ChatGPT 回复超时");
}

function askChatGpt(lines, visualPath) {
    var token = "QQBOT_" + Date.now().toString(36).toUpperCase();

    // 图片/静态表情轮：通过Android分享Intent把裁剪图直接作为视觉附件送给ChatGPT。
    // 分享入口可能切换ChatGPT会话，因此该轮使用自包含提示词，并让下一次文字轮重新初始化长期规则。
    if (visualPath) {
        var imagePrompt = buildImageTurnPrompt(lines, token);
        logLine(VERSION + " 图片请求编号=" + token);
        sendChatGptImagePrompt(visualPath, imagePrompt);
        chatGptRequestsSinceSetup++;
        chatGptSessionReady = false;
        return waitForChatGptDecision(token);
    }

    // 纯文字轮继续沿用“完整规则初始化一次 + 精简OCR请求”。
    if (!chatGptSessionReady || chatGptRequestsSinceSetup >= CFG.setupRefreshEvery) {
        setStatus(chatGptSessionReady ?
            "已完成30次请求，正在刷新GPT完整规则" :
            "正在初始化GPT完整规则");
        initializeChatGptSession();
    } else {
        openChatGptForBot();
    }

    var prompt = buildTurnPrompt(lines, token);
    logLine(VERSION + " 精简请求编号=" + token +
        " 距上次完整规则=" + chatGptRequestsSinceSetup);

    sendChatGptPrompt(prompt);
    chatGptRequestsSinceSetup++;
    return waitForChatGptDecision(token);
}


// 只接受当前请求编号。逆序遍历并直接返回，避免嵌套块向外层变量写回。
function findLatestProtocolNode(token) {
    var expected = String(token);
    try {
        var nodes = packageName(CFG.chatgptPackage).find();
        logLine("读取节点=" + nodes.size() + " 前台=" + currentPackage());
        for (var i = nodes.size() - 1; i >= 0; i--) {
            try {
            var n = nodes.get(i);
            if (!n) continue;
            if (String(n.className()) === "android.widget.EditText") continue;
            var values = [String(n.text() || ""), String(n.desc() || "")];
            for (var j = 0; j < values.length; j++) {
                var parsed = parseProtocolNodeText(values[j]);
                if (!parsed) continue;
                var actual = String(parsed.signature.split("|")[0]);
                var matches = actual === expected;
                logLine("协议=" + JSON.stringify(parsed) + " 期待=" + JSON.stringify(expected) + " 匹配=" + matches);
                if (matches) return parsed;
            }
            } catch (e) { logLine("节点" + i + "读取异常=" + e); }
        }
    } catch (e) {
        logLine("枚举ChatGPT协议节点失败：" + e);
    }
    return null;
}

function parseProtocolNodeText(value) {
    var s = String(value || "")
        .replace(/^```\w*\s*|```$/g, "")
        .replace(/[\r\n\t]+/g, "")
        .trim();
    var m = s.match(/^QQBOT_([A-Z0-9]+)\s*[|｜]\s*(NO_REPLY)\s*$/i);
    if (m) {
        var signature = "QQBOT_" + m[1].toUpperCase() + "|NO_REPLY";
        return { signature: signature, body: "NO_REPLY" };
    }
    m = s.match(/^QQBOT_([A-Z0-9]+)\s*[|｜]\s*(REPLY|INTERJECT)\s*[:：]\s*([\s\S]+)$/i);
    if (!m || !m[3].trim()) return null;
    var kind = m[2].toUpperCase();
    var message = m[3].trim();
    return {
        signature: "QQBOT_" + m[1].toUpperCase() + "|" + kind + ":" + message,
        body: kind + ":" + message
    };
}

function parseDecision(raw, token) {
    var body = raw.slice((token + "|").length).trim();
    if (/^NO_REPLY/i.test(body)) return { type: "none" };
    var m = body.match(/^(REPLY|INTERJECT)\s*:\s*([\s\S]+)/i);
    if (!m) return { type: "none" };
    var msg = m[2].replace(/^['\"“”]+|['\"“”]+$/g, "").trim();
    if (!msg) return { type: "none" };
    if (msg.length > 350) msg = msg.slice(0, 350);
    return { type: m[1].toUpperCase() === "INTERJECT" ? "interject" : "reply", text: msg };
}

function openQqAndCheck() {
    app.launchPackage(CFG.qqPackage);
    waitForPackage(CFG.qqPackage, 12000);
    sleep(CFG.appSwitchWaitMs);
    if (!findEditable()) throw new Error("QQ没有停在群聊页面，或找不到输入框");
}

function returnToQq() {
    logLine("准备返回QQ，前台=" + currentPackage());
    var launched = app.launchPackage(CFG.qqPackage);
    logLine("启动QQ返回值=" + launched);
    var deadline = Date.now() + 8000;
    while (running && Date.now() < deadline && !isQqPageActive()) sleep(250);
    logLine("跳转后应用=" + currentPackage());
    if (!isQqPageActive()) throw new Error("已读取回复，但QQ未进入前台");
    dismissQqKeyboard();
    sleep(CFG.appSwitchWaitMs);
    ensureQqAtBottom();
}

// 从QQ无障碍控件树定位当前聊天输入框。
// 多个编辑框同时出现时选最靠下的一个；不拿其他App的文本框冒充QQ输入框。
function getQqInputBounds() {
    var nodes;
    try {
        nodes = packageName(CFG.qqPackage)
            .className("android.widget.EditText").visibleToUser(true).find();
    } catch (_) { return null; }
    var chosen = null;
    for (var i = 0; i < nodes.size(); i++) {
        var n = nodes.get(i);
        if (!n || !n.enabled()) continue;
        var b = n.bounds();
        if (!b || b.width() < 30 || b.height() < 15) continue;
        // 群聊的发送输入框位于屏幕中下部；顶部搜索框不算。
        if (b.top < device.height * 0.27 || b.top > device.height * 0.95) continue;
        if (!chosen || b.bottom > chosen.bottom) chosen = b;
    }
    return chosen;
}

function hasVisibleQqInput() {
    return !!getQqInputBounds();
}

function isQqPageActive() {
    var pkg = String(currentPackage());
    return (pkg === CFG.qqPackage || pkg === "com.huawei.ohos.inputmethod")
        && hasVisibleQqInput();
}

// 检测到华为输入法时正常收起；个别华为版本不暴露输入法包名，
// 则仅在QQ输入框明显上移时尝试收起。即使没收起，readQqScreen也会避开键盘。
function dismissQqKeyboard() {
    if (!isQqPageActive()) return false;
    var b = getQqInputBounds();
    if (!b) return false;
    var keyboardVisible = false;
    try {
        keyboardVisible = packageName("com.huawei.ohos.inputmethod")
            .visibleToUser(true).exists();
    } catch (_) {}
    if (!keyboardVisible && b.top > device.height * 0.68) return false;
    logLine("QQ输入框上移或输入法可见，尝试收起键盘");
    back();
    sleep(450);
    return true;
}

function sendQqText(message) {
    if (!isQqPageActive()) throw new Error("QQ不在群聊页面，取消发送");
    var input = findQqEditable();
    if (!input) throw new Error("找不到 QQ 输入框");
    input.click();
    sleep(180);
    input.setText(message);
    sleep(300);
    if (!clickSendButton(input, /发送|发送消息|Send|Send message/i)) {
        throw new Error("找不到 QQ 发送按钮；为防止乱点，脚本已停止");
    }
    sleep(700);
    dismissQqKeyboard();
}

// 后备方案：兼容只有箭头图标、没有“发送”文字的按钮。
// 先按文字/无障碍描述查找；失败后，在输入框右侧及其下方的输入面板内寻找可点击控件。
function clickSendButton(input, pattern, fixedFallback) {
    if (clickNamedButton(pattern)) return true;
    if (!input) return false;

    var ib = input.bounds();
    var inputPkg = String(input.packageName() || "");
    var screenW = device.width;
    var screenH = device.height;
    var nodes = classNameMatches(/.*/).find();
    var best = null;
    var bestScore = -Infinity;

    for (var i = 0; i < nodes.size(); i++) {
        var n = nodes.get(i);
        if (!n || !n.visibleToUser() || !n.enabled() || !n.clickable()) continue;
        // Compose 子控件有时不返回包名；键盘弹出后 currentPackage() 也可能不可靠。
        var nodePkg = String(n.packageName() || "");
        if (nodePkg && inputPkg && nodePkg !== inputPkg) continue;

        var b = n.bounds();
        if (!b || b.width() <= 0 || b.height() <= 0) continue;
        if (b.width() > screenW * 0.35 || b.height() > screenH * 0.20) continue;

        // ChatGPT 的箭头位于文字编辑区域下方，所以允许向下扩展一个输入工具栏高度。
        var maxDown = Math.max(180, Math.min(320, ib.height() * 0.55));
        if (b.centerY() < ib.top - 60 || b.centerY() > ib.bottom + maxDown) continue;
        if (b.centerX() <= ib.centerX() || b.centerX() < screenW * 0.62) continue;

        var targetY = Math.min(screenH, ib.bottom + 55);
        var yDistance = Math.abs(b.centerY() - targetY);
        var areaPenalty = b.width() * b.height() * 0.001;
        var score = b.centerX() * 2 - yDistance - areaPenalty;
        if (score > bestScore) {
            best = n;
            bestScore = score;
        }
    }

    if (best && best.click()) return true;

    // P50e 专用兜底：控件树完全不暴露发送箭头时，按当前屏幕比例点击。
    // 比例取自 696×1536 截图中的发送键中心 (623, 945)，可适配同纵横比的系统缩放。
    if (fixedFallback && inputPkg === CFG.chatgptPackage && String(input.text() || "").trim()) {
        var x = Math.round(device.width * fixedFallback.xRatio);
        var y = Math.round(device.height * fixedFallback.yRatio);
        logLine("控件识别失败，使用P50e固定比例发送点：" + x + "," + y);
        return click(x, y);
    }
    return false;
}

function clickNamedButton(pattern) {
    var selectors = [textMatches(pattern), descMatches(pattern)];
    for (var i = 0; i < selectors.length; i++) {
        var nodes = selectors[i].find();
        for (var j = nodes.size() - 1; j >= 0; j--) {
            var n = nodes.get(j);
            if (!n || !n.visibleToUser() || !n.enabled()) continue;
            if (n.click()) return true;
            var p = n.parent();
            if (p && p.clickable() && p.click()) return true;
        }
    }
    return false;
}

// v0.4.2：实测ChatGPT发送键desc为“发送消息”，但clickable=false。
// 锁定该节点后读取实时bounds，优先逐级点击父容器，最后点击节点中心。
function clickChatGptSend() {
    var nodes;
    try {
        nodes = packageName(CFG.chatgptPackage).desc("发送消息").find();
    } catch (_) {
        return false;
    }
    for (var i = nodes.size() - 1; i >= 0; i--) {
        var n = nodes.get(i);
        if (!n || !n.visibleToUser() || !n.enabled()) continue;

        var p = n;
        for (var depth = 0; p && depth < 8; depth++) {
            if (p.clickable() && p.enabled() && p.click()) return true;
            p = p.parent();
        }

        var b = n.bounds();
        if (b && b.width() > 0 && b.height() > 0 && click(b.centerX(), b.centerY())) {
            logLine("已按发送消息节点中心点击：" + b.centerX() + "," + b.centerY());
            return true;
        }
    }
    return false;
}

// 只允许通过明确的“回到底部/新消息/未读消息”按钮回到最新位置。
// 不执行任何 swipe 或坐标滑动；找不到明确按钮就保持当前页面不动。
function ensureQqAtBottom() {
    if (!isQqPageActive()) return false;
    var pattern = /^(回到底部|返回底部|跳到最新|查看最新消息|\d+条新消息|\d+条未读消息)$/;
    var clicked = false;
    try {
        var selectors = [textMatches(pattern), descMatches(pattern)];
        for (var k = 0; k < selectors.length && !clicked; k++) {
            var ns = selectors[k].find();
            for (var i = 0; i < ns.size(); i++) {
                var n = ns.get(i);
                if (!n || !n.visibleToUser()) continue;
                var p = n;
                for (var d = 0; p && d < 3; d++, p = p.parent()) {
                    if (p.clickable() && p.click()) { clicked = true; break; }
                }
            }
        }
    } catch (e) {
        logLine("定位聊天底部按钮失败：" + e);
    }
    if (clicked) sleep(280);
    return clicked;
}

// OCR 只裁剪输入框上方区域；旧的80.5%固定限制会漏掉最下方新消息，已移除。
function getQqOcrRegion(imgW, imgH) {
    var b = getQqInputBounds();
    if (!b) return null;
    var scale = imgH / Math.max(1, device.height);
    var top = Math.floor(imgH * CFG.chatTopRatio);
    var inputTop = Math.floor(b.top * scale);
    var margin = Math.max(8, Math.round(CFG.chatInputGapPx * scale));
    var bottom = Math.min(Math.floor(imgH * 0.975), inputTop - margin);
    if (bottom - top < imgH * CFG.minChatAreaRatio) return null;
    return { left: 0, top: top, width: imgW, height: bottom - top,
             bottom: bottom, inputTop: inputTop };
}


// 本地判断“聊天内容是否真的变化”用的规范化。
// 只用于决定要不要请求GPT，不会改变发给GPT看的OCR原文。
function normalizeChatFingerprintText(raw) {
    var s = String(raw || "")
        .replace(/\u00A0/g, " ")
        .replace(/[ \t]+/g, " ")
        .replace(/[，,。．]/g, "")
        .replace(/[：:]/g, ":")
        .replace(/[（）()【】\[\]「」『』]/g, "")
        .trim()
        .toLowerCase();

    // 去掉脚本自动附加的版本号，避免版本文字影响本地变化判断。
    s = s.replace(/\s*v\d+(?:\.\d+){1,2}\s*$/i, "").trim();
    return s;
}

// 过滤明显属于QQ界面/时间的瞬时文字。
// 不过滤普通短消息和纯数字消息，避免漏掉群友真实发言。
function isTransientQqLine(raw) {
    var s = String(raw || "").trim();
    if (!s) return true;

    // 常见时间：10:28、上午10:28、下午 3:05、昨天 10:28 等。
    if (/^(?:今天|昨天|前天)?\s*(?:上午|下午|晚上|凌晨|中午)?\s*\d{1,2}:\d{2}$/.test(s)) return true;

    // 常见QQ聊天界面提示，不作为“聊天内容变化”。
    if (/^(?:回到底部|返回底部|跳到最新|查看最新消息|\d+条新消息|\d+条未读消息|发送|图片|相机|语音|表情|加号|返回)$/.test(s)) return true;

    // 顶部群待办/系统栏这类持续存在但会偶尔刷新。
    if (/^(?:回群待办|群待办|本群新法案)/.test(s)) return true;

    return false;
}

// 忽略机器人自己刚刚发出的内容，避免“自己发一句 -> 又触发一次GPT请求”。
// 对较长文本允许OCR分段后的包含匹配；过短文本不做模糊忽略，防止误伤群友。
function isOwnRecentBotLine(raw) {
    var line = normalizeChatFingerprintText(raw);
    var own = normalizeChatFingerprintText(state.lastBotText || "");
    if (!line || !own) return false;
    if (line === own) return true;
    if (line.length >= 6 && own.length >= 6 &&
        (own.indexOf(line) >= 0 || line.indexOf(own) >= 0)) return true;
    return false;
}

function buildLocalChatFingerprint(lines) {
    var kept = [];
    for (var i = 0; i < lines.length; i++) {
        var raw = String(lines[i] || "").trim();
        if (!raw || isTransientQqLine(raw) || isOwnRecentBotLine(raw)) continue;
        var s = normalizeChatFingerprintText(raw);
        if (!s) continue;
        kept.push(s);
    }

    // 只取屏幕底部最近内容，降低顶部昵称/公告轻微抖动造成的误触发。
    kept = kept.slice(-18);
    return {
        lines: kept,
        signature: hashString(kept.join("\n"))
    };
}

// 在QQ聊天区寻找“足够大的ImageView”，用于识别普通图片、截图、静态表情。
// 小头像、工具栏图标会被尺寸阈值排除。该规则是实验性的，后续可根据P50e实测继续收紧。
function findLatestQqVisualCandidate() {
    var input = getQqInputBounds();
    if (!input) return null;

    var topLimit = Math.round(device.height * CFG.chatTopRatio);
    var bottomLimit = input.top - CFG.chatInputGapPx;
    var minW = Math.max(110, Math.round(device.width * 0.18));
    var minH = Math.max(80, Math.round(device.height * 0.05));
    var maxW = Math.round(device.width * 0.92);
    var maxH = Math.round(device.height * 0.55);
    var nodes;

    try {
        nodes = packageName(CFG.qqPackage)
            .className("android.widget.ImageView")
            .visibleToUser(true).find();
    } catch (_) {
        return null;
    }

    var best = null;
    for (var i = 0; i < nodes.size(); i++) {
        var n = nodes.get(i);
        if (!n) continue;
        var b = n.bounds();
        if (!b || b.width() < minW || b.height() < minH) continue;
        if (b.width() > maxW || b.height() > maxH) continue;
        if (b.top < topLimit || b.bottom > bottomLimit) continue;

        // 头像通常接近方形且很小；这里已经用尺寸排除了大多数头像。
        if (!best || b.bottom > best.bottom ||
            (b.bottom === best.bottom && b.width() * b.height() > best.width() * best.height())) {
            best = b;
        }
    }
    return best;
}

function hashVisualCandidate(img, bounds) {
    if (!img || !bounds) return "";
    try {
        var sx = img.getWidth() / Math.max(1, device.width);
        var sy = img.getHeight() / Math.max(1, device.height);
        var parts = [];

        // 12×12采样并粗量化颜色。只基于内容，不把屏幕坐标写进签名；
        // 这样旧图片因新文字到来而整体上移，不会被误判成一张新图。
        for (var gy = 0; gy < 12; gy++) {
            for (var gx = 0; gx < 12; gx++) {
                var dx = bounds.left + (gx + 0.5) * bounds.width() / 12;
                var dy = bounds.top + (gy + 0.5) * bounds.height() / 12;
                var x = Math.max(0, Math.min(img.getWidth() - 1, Math.round(dx * sx)));
                var y = Math.max(0, Math.min(img.getHeight() - 1, Math.round(dy * sy)));
                var c = images.pixel(img, x, y);
                var r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                parts.push(((r >> 5) << 6) | ((g >> 5) << 3) | (b >> 5));
            }
        }
        return hashString(parts.join(","));
    } catch (e) {
        logLine("计算视觉签名失败：" + e);
        return "";
    }
}

function captureLatestQqVisualToFile() {
    if (!isQqPageActive()) return null;
    var b = findLatestQqVisualCandidate();
    if (!b) return null;

    var img = captureScreen();
    if (!img) return null;
    var clip = null;
    try {
        var sx = img.getWidth() / Math.max(1, device.width);
        var sy = img.getHeight() / Math.max(1, device.height);
        var left = Math.max(0, Math.round(b.left * sx));
        var top = Math.max(0, Math.round(b.top * sy));
        var right = Math.min(img.getWidth(), Math.round(b.right * sx));
        var bottom = Math.min(img.getHeight(), Math.round(b.bottom * sy));
        if (right - left < 40 || bottom - top < 40) return null;

        clip = images.clip(img, left, top, right - left, bottom - top);
        files.ensureDir(CFG.visualCacheDir);
        images.save(clip, CFG.visualCachePath, "png", 82);
        return CFG.visualCachePath;
    } finally {
        if (clip) { try { clip.recycle(); } catch (_) {} }
        try { img.recycle(); } catch (_) {}
    }
}

function readQqScreen() {
    if (!isQqPageActive()) return { valid: false, lines: [], signature: "", chatSignature: "" };
    var img = captureScreen();
    if (!img) throw new Error("截图失败");
    var clip = null, raw, region, visualSignature = "";
    try {
        var w = img.getWidth(), h = img.getHeight();
        region = getQqOcrRegion(w, h);
        if (!region) return { valid: false, lines: [], signature: "", chatSignature: "", visualSignature: "" };

        var visualCandidate = findLatestQqVisualCandidate();
        visualSignature = hashVisualCandidate(img, visualCandidate);

        clip = images.clip(img, region.left, region.top, region.width, region.height);
        ocr.mode = "mlkit";
        raw = ocr.detect(clip);
    } finally {
        if (clip) { try { clip.recycle(); } catch (_) {} }
        try { img.recycle(); } catch (_) {}
    }
    var lines = normalizeOcr(raw);

    // 图片消息可能没有任何可OCR文字，因此只要存在可靠的大图视觉签名，也视为有效聊天画面。
    if (!lines.length && !visualSignature) {
        return { valid: false, lines: [], signature: "", chatSignature: "", visualSignature: "", region: region };
    }
    if (!lines.length && visualSignature) lines = ["[图片/静态表情]"];

    var local = buildLocalChatFingerprint(lines);
    var combined = local.signature + "|" + (visualSignature || "");
    return { valid: true, lines: lines,
        signature: hashString(lines.join("\n")),
        chatSignature: hashString(combined),
        visualSignature: visualSignature || "",
        chatFingerprintLines: local.lines,
        region: region };
}

function normalizeOcr(raw) {
    if (!raw) return [];
    var arr = Array.isArray(raw) ? raw : (raw.results || raw.data || []);
    var out = [];
    for (var i = 0; i < arr.length; i++) {
        var x = arr[i] || {};
        var t = String(x.text || x.label || x.words || x.value || "").trim().replace(/\s+/g, " ");
        if (!t || /^(发送|图片|相机|语音|表情|加号|返回)$/.test(t)) continue;
        var b = x.bounds || x.rect || x.boundingBox || {};
        var y = Number(b.top != null ? b.top : (Array.isArray(b) ? b[1] : i * 10));
        var x0 = Number(b.left != null ? b.left : (Array.isArray(b) ? b[0] : 0));
        out.push({ text: t, y: isNaN(y) ? i * 10 : y, x: isNaN(x0) ? 0 : x0 });
    }
    out.sort((a, b) => Math.abs(a.y - b.y) > 8 ? a.y - b.y : a.x - b.x);
    return out.map(x => x.text).slice(-CFG.maxOcrLines);
}

function ensureOcrReady() {
    try {
        if (!ocr || typeof ocr.detect !== "function") throw 0;
        ocr.mode = "mlkit";
    } catch (_) {
        throw new Error("AutoJs6 内置 ML Kit OCR 不可用，请确认使用 AutoJs6 6.7.0 后重启应用");
    }
}

function testOcr() {
    try {
        if (!getCapturePermission()) throw new Error("没有截图权限");
        ensureOcrReady();
        app.launchPackage(CFG.qqPackage);
        waitForPackage(CFG.qqPackage, 12000);
        sleep(CFG.appSwitchWaitMs);
        ensureQqAtBottom();
        var shot = readQqScreen();
        var range = shot.region ? ("识别区域：Y=" + shot.region.top + "～" + shot.region.bottom + "；输入框顶部Y=" + shot.region.inputTop + "\n\n") : "无法定位QQ聊天输入框，本次未进行OCR。请打开目标群聊。\n\n";
        dialogs.alert("OCR 测试结果", range + (shot.lines.length ? shot.lines.join("\n") : "没有识别到聊天文字"));
    } catch (e) { dialogs.alert("OCR 测试失败", String(e)); }
}

function findQqEditable() {
    try {
        var nodes = packageName(CFG.qqPackage)
            .className("android.widget.EditText").visibleToUser(true).find();
        for (var i = nodes.size() - 1; i >= 0; i--) {
            var n = nodes.get(i);
            if (!n || !n.enabled()) continue;
            var b = n.bounds();
            if (b && b.top > device.height * 0.27) return n;
        }
    } catch (_) {}
    return null;
}

function findEditable() {
    var nodes = className("android.widget.EditText").find();
    for (var i = nodes.size() - 1; i >= 0; i--) {
        var n = nodes.get(i);
        if (n && n.visibleToUser() && n.enabled()) return n;
    }
    return null;
}

function collectVisibleValues() {
    var values = [], nodes = classNameMatches(/.*/).find();
    for (var i = 0; i < nodes.size(); i++) {
        var n = nodes.get(i);
        if (!n || !n.visibleToUser()) continue;
        var s = String(n.text() || n.desc() || "").trim();
        if (s) values.push(s);
    }
    return values;
}

function hashString(s) {
    var h = 2166136261;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return (h >>> 0).toString(16);
}

function logLine(s) {
    try {
        files.ensureDir(CFG.logFile);
        files.append(CFG.logFile, new Date().toLocaleString() + "  " + s + "\n");
    } catch (_) {}
}




