"ui";

/* QQ × ChatGPT 自动群聊 v0.4.21 - AutoJs6 6.7+
 * 单群版：最新消息优先、聊天区动态OCR；v0.4.21移除发送前二次OCR复核。
 * 追加祀式活泼傲气人设、有限轮次本地上下文、消息尾部版本号。
 * 主动互动拉满：公开话题默认允许插嘴，显著降低NO_REPLY；不增加多群独立配置。
 * 尚未在用户手机上实机验证，请先测试OCR后再监听。
 */
var VERSION = "v0.4.21";
var CFG = {
    qqPackage: "com.tencent.mobileqq",
    chatgptPackage: "com.openai.chatgpt",
    quietMs: 450,
scanIntervalMs: 200,
    chatgptTimeoutMs: 90000,
    appSwitchWaitMs: 1700,
    chatTopRatio: 0.105,
    chatInputGapPx: 16,      // 聊天文字最下缘与QQ输入框顶部的保护距离
    minChatAreaRatio: 0.18, // 聊天区域太小则跳过，不读键盘
    interjectChance: 1.00,
    maxOcrLines: 30,
    recentTurnsLimit: 4,
    botAliases: "GPT-6A,GPT,ChatGPT",
    ownerNickname: "请填写你的QQ昵称", // 这是QQ群昵称，不是QQ号；只用于聊天身份识别
    logFile: "/sdcard/AutoJs6/qq_chatgpt_v4.log"
};

var running = false;
var worker = null;
var captureGranted = false;
// 只有单群的一份持久状态。历史存本机 AutoJs6，不传到任何额外服务。
var memoryStore = storages.create("qq_chatgpt_single_v0415");
var state = { lastBotText: "", lastWasInterjection: false, recentTurns: [] };
loadLocalState();

ui.layout(
    <vertical padding="18">
        <text text="QQ × ChatGPT 自动群聊 v0.4.21" textSize="22sp" textStyle="bold" />
        <text marginTop="10" text="运行前让 QQ 停在目标群、ChatGPT 停在专用对话。需要无障碍和截图权限；OCR 使用 AutoJs6 自带的 ML Kit。" textSize="14sp" />
        <text id="status" marginTop="14" text="状态：未运行" textColor="#777777" />
        <button id="testOcr" marginTop="16" text="第一步：测试 OCR" />
        <button id="start" text="第二步：开始监听" />
        <button id="stop" text="停止" enabled="false" />
        <text marginTop="12" text="单群版；发送前复核最新消息；每条群消息追加版本号。音量上键可紧急停止。" textColor="#D32F2F" />
    </vertical>
);

ui.testOcr.click(() => threads.start(testOcr));
ui.start.click(() => startBot());
ui.stop.click(() => stopBot("已手动停止"));

events.observeKey();
events.onKeyDown("volume_up", () => stopBot("已用音量上键停止"));

function setStatus(s) {
    ui.run(() => ui.status.setText("状态：" + s));
    logLine(s);
}

function setButtons(isRunning) {
    ui.run(() => {
        ui.start.setEnabled(!isRunning);
        ui.stop.setEnabled(isRunning);
        ui.testOcr.setEnabled(!isRunning);
    });
}

function getCapturePermission() {
    if (captureGranted) return true;
    captureGranted = requestScreenCapture(false);
    return captureGranted;
}

function startBot() {
    if (running) return;
    if (!auto.service) {
        toast("请先开启 AutoJs6 无障碍服务");
        app.startActivity({ action: "android.settings.ACCESSIBILITY_SETTINGS" });
        return;
    }
    if (!getCapturePermission()) {
        toast("没有取得截图权限");
        return;
    }
    running = true;
    setButtons(true);
    worker = threads.start(mainLoop);
}

function stopBot(reason) {
    running = false;
    if (worker) {
        try { worker.interrupt(); } catch (_) {}
        worker = null;
    }
    setButtons(false);
    setStatus(reason || "已停止");
}

function mainLoop() {
    try {
        ensureOcrReady();
        openQqAndCheck();
        setStatus("定位到最新消息，等待新发言");
        ensureQqAtBottom();
        var observedSignature = null;
        var processedSignature = null;
        var lastChangeAt = Date.now();
        while (running) {
            if (!isQqPageActive()) {
                setStatus("QQ 群聊未显示，暂停识别");
                sleep(700);
                continue;
            }
            dismissQqKeyboard();
            if (!isQqPageActive()) { sleep(400); continue; }
            // 只在明确识别到“回到底部/新消息”等按钮时点击。
            // 禁止任何 swipe/自动滑动，避免误触群聊界面。
            var moved = ensureQqAtBottom();
            if (moved) sleep(280);
            var shot = readQqScreen();
            if (!shot.valid || !shot.lines.length) {
                setStatus("未能确认聊天区域，等待下一次识别");
                sleep(700);
                continue;
            }
            // 初次读到群聊仅作为基线，不能把历史消息当作新消息。
            if (observedSignature === null) {
                observedSignature = shot.signature;
                processedSignature = shot.signature;
                lastChangeAt = Date.now();
                setStatus("监听中：已对齐最新消息");
            } else if (shot.signature !== observedSignature) {
                var now = Date.now();
                observedSignature = shot.signature;
                lastChangeAt = now;
                setStatus("发现新消息，短暂合并后立即处理");
            } else if (shot.signature !== processedSignature) {
                var now2 = Date.now();
                var quietEnough = now2 - lastChangeAt >= CFG.quietMs;
                if (quietEnough) {
                    // 标记的只是这次交给模型的快照，不是切回QQ时出现的新消息。
                    processedSignature = shot.signature;
                        handleBatch(shot);
                    if (!running) break;
                    // 如果切应用期间有新消息，绝不把新画面直接当作已处理。
                    var after = readQqScreen();
                    if (after.valid && after.lines.length &&
                        after.signature !== observedSignature) {
                        observedSignature = after.signature;
                        lastChangeAt = Date.now();
                        setStatus("发现后续消息，快速进入下一轮处理");
                    }
                }
            }
            sleep(CFG.scanIntervalMs);
        }
    } catch (e) {
        logLine("FATAL: " + e + "\n" + (e.stack || ""));
        toast("脚本停止：" + e);
        stopBot("发生错误，请查看日志");
    }
}

function handleBatch(shot) {
    var allowInterject = Math.random() < CFG.interjectChance;
    setStatus("ChatGPT 正在判断是否回复");
    var result;
    try {
        result = askChatGpt(shot.lines, allowInterject);
    } catch (readError) {
        if (!running) return;
        logLine("读取失败，先尝试返回QQ：" + readError);
        try { returnToQq(); }
        catch (jumpError) { logLine("失败后的返回QQ也失败：" + jumpError); }
        throw readError;
    }
    if (!running) return;
    returnToQq();
    if (!result || result.type === "none") {
        setStatus("选择沉默，继续监听");
        return;
    }
    // ChatGPT 已明确返回 REPLY/INTERJECT 后直接发送，
    // 不再做发送前二次 OCR 复核，避免因 OCR 抖动吞掉已生成回复。
    var textToSend = appendVersion(result.text);
    if (!textToSend || !running) return;
    sendQqText(textToSend);
    state.lastBotText = textToSend;
    state.lastWasInterjection = result.type === "interject";
    rememberTurn(shot.lines, textToSend);
    setStatus("已发送（" + VERSION + "），继续监听");
}

function loadLocalState() {
    try {
        var saved = memoryStore.get("history", null);
        if (!saved || typeof saved !== "object") return;
        state.lastBotText = String(saved.lastBotText || "").slice(-380);
        state.lastWasInterjection = saved.lastWasInterjection === true;
        state.recentTurns = Array.isArray(saved.recentTurns) ?
            saved.recentTurns.slice(-CFG.recentTurnsLimit) : [];
    } catch (e) { logLine("加载本地上下文失败：" + e); }
}

function rememberTurn(lines, reply) {
    state.recentTurns.push({
        context: lines.slice(-7).join(" / ").slice(-380),
        bot: String(reply || "").slice(0, 360)
    });
    state.recentTurns = state.recentTurns.slice(-CFG.recentTurnsLimit);
    try { memoryStore.put("history", state); }
    catch (e) { logLine("保存本地上下文失败：" + e); }
}

function appendVersion(raw) {
    var s = String(raw || "").replace(/\s+/g, " ").trim();
    if (!s) return "";
    // 防止GPT自己生成版本号后脚本又附加一次；以实际脚本版本为准。
    s = s.replace(/\s*[（(]\s*v\d+\.\d+\.\d+\s*[）)]\s*$/i, "").trim();
    var suffix = "（" + VERSION + "）";
    if (s.length + suffix.length > 350) s = s.slice(0, 350 - suffix.length);
    return s + suffix;
}

function buildPrompt(lines, allowInterject, token) {
    var recent = state.recentTurns.map(function (x, i) {
        return (i + 1) + ". 之前可见聊天：" + x.context + "\n   你当时说：" + x.bot;
    }).join("\n");
    return [
        "你正在一个QQ群里作为普通群友聊天。以下是手机OCR读取的群聊画面，可能混有时间、等级、按钮和少量错字。",
        "你的群昵称是GPT-6A；别人也可能称呼你GPT或ChatGPT。你与下述使用者是两个不同的群成员。",
        "机器人的使用者（主人）在本群的显示昵称是：" + CFG.ownerNickname + "。这是群昵称，不是QQ号码，也不是你的名字。",
        "只有OCR明确显示“" + CFG.ownerNickname + "”是某条消息的发送者，才认定它来自使用者；@、引用、系统提示中的昵称都不是身份依据。无法确定发送者就不要硬猜。",
        "使用者也只是普通群友；他和别人聊天时，不要仅因为是使用者就插嘴。昵称不用于授予管理权限或披露私密信息。",
        "你的日常人设：高度参考《明日方舟：终末地》中祀的活泼、好奇、傲气、调皮、嘴硬与小恶作剧感；但你始终是GPT-6A，不是祀，也不用自称角色名。",
        "聊天表现：自信、聪明、有自己的看法，熟人可以轻微捉弄、互相斗嘴，被夸会有些得意，被吐槽会机灵回嘴；遇到严肃问题认真解决。",
        "人设不要表演得机械：不强制哼/笨蛋/本小姐等口癖，不每句卖萌，不无故嘲讽陌生人，不捏造事实，不反复自称AI，也不把真欺骗当恶作剧。",
        "规则：",
        "1. 严格以【本次最新OCR】中的最新内容判断是否回应。之前上下文只用于理解人物与话题，绝不能当成本次的新消息回复。",
        "2. 点名GPT-6A、GPT、ChatGPT或明显承接你上句时，优先直接回复。不要回复你自己发的话、不要自言自语；有人明确只点名其他人求助时不要代答。",
        "3. 本轮允许主动插嘴：" + (allowInterject ? "是" : "否") + "。当为‘是’时，只要最新公开话题能看懂、能自然接上一句，就优先用INTERJECT参与；可以接梗、吐槽、表达看法、追问、顺势开个小玩笑，不要求信息价值很高。",
        "4. 尽量少用NO_REPLY。只有这些情况才优先沉默：最新内容明显是你自己刚发的；明确只在问另一个人且不适合旁人插话；OCR几乎无法辨认；当前没有任何具体可接内容。普通群友之间的公开闲聊、吐槽、游戏讨论、玩梗都属于可以参与的话题。",
        "5. 你上一条是否属于主动插嘴：" + (state.lastWasInterjection ? "是" : "否") + "。如果上次主动插嘴后没人接你，不要机械地永久沉默；只有话题仍停留在你刚才那句附近时先闭嘴。如果群里已经出现新的明确内容或话题继续发展，可以再次自然加入。",
        "6. 回复像真实群友，尽量一两句，具体、自然，避免说教和客服腔；主动参与时宁可说一句有趣的短话，也不要因为要求不高就频繁NO_REPLY。",
        "7. OCR可能有错字或杂项，键盘字符、按钮、昵称标题和系统界面不是群友发言。昵称与正文可能是分开的相邻行，不要单凭相邻就断言发送者。",
        "8. 不要在回复正文里加任何版本号；发送脚本会自动在消息末尾添加当前脚本版本。",
        "",
        "【少量历史互动，仅辅助理解，不要回应其中的旧话题】",
        recent || "无",
        "",
        "严格只输出一种格式，不要Markdown：",
        token + "|NO_REPLY",
        token + "|REPLY:要发送的文字",
        token + "|INTERJECT:主动插嘴的文字",
        "REPLY只用于回应对你说话的人；INTERJECT用于主动加入当前公开话题。",
        "",
        "你上一条发言：" + (state.lastBotText || "无"),
        "",
        "【本次最新OCR（从上到下，最后面的文字更接近最新消息）】",
        lines.slice(-CFG.maxOcrLines).join("\n")
    ].join("\n");
}

function askChatGpt(lines, allowInterject) {
    var token = "QQBOT_" + Date.now().toString(36).toUpperCase();
    var prompt = buildPrompt(lines, allowInterject, token);
    app.launchPackage(CFG.chatgptPackage);
    waitForPackage(CFG.chatgptPackage, 12000);
    sleep(CFG.appSwitchWaitMs);

    logLine(VERSION + " 请求编号=" + token);

    var input = findEditable();
    if (!input) throw new Error("找不到 ChatGPT 输入框");
    input.click();
    sleep(250);
    input.setText(prompt);
    sleep(350);
    if (!clickChatGptSend() && !clickSendButton(
        input,
        /发送|发送消息|发送提示|Send|Send message|Send prompt|提交|Submit/i,
        { xRatio: 0.895, yRatio: 0.615 }
    )) {
        throw new Error("找不到 ChatGPT 发送按钮");
    }

    var deadline = Date.now() + CFG.chatgptTimeoutMs;
    var lastSignature = "", stableSince = 0;
    while (running && Date.now() < deadline) {
        sleep(900);
        var latest = findLatestProtocolNode(token);
        if (!latest) continue;
        logLine("匹配函数已返回=" + JSON.stringify(latest));
        if (latest.body !== "NO_REPLY") {
            if (latest.signature !== lastSignature) {
                lastSignature = latest.signature;
                stableSince = Date.now();
                continue;
            }
            logLine("回复稳定等待毫秒=" + (Date.now() - stableSince));
            if (Date.now() - stableSince < 3000) continue;
        }
        logLine("已枚举到新ChatGPT决策：" + latest.signature);
        return parseDecision(token + "|" + latest.body, token);
    }
    if (!running) return null;
    throw new Error("等待 ChatGPT 回复超时");
}

// 只接受当前请求编号。逆序遍历并直接返回，避免嵌套块向外层变量写回。
function findLatestProtocolNode(token) {
    var expected = String(token);
    try {
        var nodes = packageName(CFG.chatgptPackage).find();
        logLine("读取节点=" + nodes.size() + " 前台=" + currentPackage());
        for (var i = nodes.size() - 1; i >= 0; i--) {
            try {
            var n = nodes.get(i);
            if (!n) continue;
            if (String(n.className()) === "android.widget.EditText") continue;
            var values = [String(n.text() || ""), String(n.desc() || "")];
            for (var j = 0; j < values.length; j++) {
                var parsed = parseProtocolNodeText(values[j]);
                if (!parsed) continue;
                var actual = String(parsed.signature.split("|")[0]);
                var matches = actual === expected;
                logLine("协议=" + JSON.stringify(parsed) + " 期待=" + JSON.stringify(expected) + " 匹配=" + matches);
                if (matches) return parsed;
            }
            } catch (e) { logLine("节点" + i + "读取异常=" + e); }
        }
    } catch (e) {
        logLine("枚举ChatGPT协议节点失败：" + e);
    }
    return null;
}

function parseProtocolNodeText(value) {
    var s = String(value || "")
        .replace(/^```\w*\s*|```$/g, "")
        .replace(/[\r\n\t]+/g, "")
        .trim();
    var m = s.match(/^QQBOT_([A-Z0-9]+)\s*[|｜]\s*(NO_REPLY)\s*$/i);
    if (m) {
        var signature = "QQBOT_" + m[1].toUpperCase() + "|NO_REPLY";
        return { signature: signature, body: "NO_REPLY" };
    }
    m = s.match(/^QQBOT_([A-Z0-9]+)\s*[|｜]\s*(REPLY|INTERJECT)\s*[:：]\s*([\s\S]+)$/i);
    if (!m || !m[3].trim()) return null;
    var kind = m[2].toUpperCase();
    var message = m[3].trim();
    return {
        signature: "QQBOT_" + m[1].toUpperCase() + "|" + kind + ":" + message,
        body: kind + ":" + message
    };
}

function parseDecision(raw, token) {
    var body = raw.slice((token + "|").length).trim();
    if (/^NO_REPLY/i.test(body)) return { type: "none" };
    var m = body.match(/^(REPLY|INTERJECT)\s*:\s*([\s\S]+)/i);
    if (!m) return { type: "none" };
    var msg = m[2].replace(/^['\"“”]+|['\"“”]+$/g, "").trim();
    if (!msg) return { type: "none" };
    if (msg.length > 350) msg = msg.slice(0, 350);
    return { type: m[1].toUpperCase() === "INTERJECT" ? "interject" : "reply", text: msg };
}

function openQqAndCheck() {
    app.launchPackage(CFG.qqPackage);
    waitForPackage(CFG.qqPackage, 12000);
    sleep(CFG.appSwitchWaitMs);
    if (!findEditable()) throw new Error("QQ没有停在群聊页面，或找不到输入框");
}

function returnToQq() {
    logLine("准备返回QQ，前台=" + currentPackage());
    var launched = app.launchPackage(CFG.qqPackage);
    logLine("启动QQ返回值=" + launched);
    var deadline = Date.now() + 8000;
    while (running && Date.now() < deadline && !isQqPageActive()) sleep(250);
    logLine("跳转后应用=" + currentPackage());
    if (!isQqPageActive()) throw new Error("已读取回复，但QQ未进入前台");
    dismissQqKeyboard();
    sleep(CFG.appSwitchWaitMs);
    ensureQqAtBottom();
}

// 从QQ无障碍控件树定位当前聊天输入框。
// 多个编辑框同时出现时选最靠下的一个；不拿其他App的文本框冒充QQ输入框。
function getQqInputBounds() {
    var nodes;
    try {
        nodes = packageName(CFG.qqPackage)
            .className("android.widget.EditText").visibleToUser(true).find();
    } catch (_) { return null; }
    var chosen = null;
    for (var i = 0; i < nodes.size(); i++) {
        var n = nodes.get(i);
        if (!n || !n.enabled()) continue;
        var b = n.bounds();
        if (!b || b.width() < 30 || b.height() < 15) continue;
        // 群聊的发送输入框位于屏幕中下部；顶部搜索框不算。
        if (b.top < device.height * 0.27 || b.top > device.height * 0.95) continue;
        if (!chosen || b.bottom > chosen.bottom) chosen = b;
    }
    return chosen;
}

function hasVisibleQqInput() {
    return !!getQqInputBounds();
}

function isQqPageActive() {
    var pkg = String(currentPackage());
    return (pkg === CFG.qqPackage || pkg === "com.huawei.ohos.inputmethod")
        && hasVisibleQqInput();
}

// 检测到华为输入法时正常收起；个别华为版本不暴露输入法包名，
// 则仅在QQ输入框明显上移时尝试收起。即使没收起，readQqScreen也会避开键盘。
function dismissQqKeyboard() {
    if (!isQqPageActive()) return false;
    var b = getQqInputBounds();
    if (!b) return false;
    var keyboardVisible = false;
    try {
        keyboardVisible = packageName("com.huawei.ohos.inputmethod")
            .visibleToUser(true).exists();
    } catch (_) {}
    if (!keyboardVisible && b.top > device.height * 0.68) return false;
    logLine("QQ输入框上移或输入法可见，尝试收起键盘");
    back();
    sleep(450);
    return true;
}

function sendQqText(message) {
    if (!isQqPageActive()) throw new Error("QQ不在群聊页面，取消发送");
    var input = findQqEditable();
    if (!input) throw new Error("找不到 QQ 输入框");
    input.click();
    sleep(180);
    input.setText(message);
    sleep(300);
    if (!clickSendButton(input, /发送|发送消息|Send|Send message/i)) {
        throw new Error("找不到 QQ 发送按钮；为防止乱点，脚本已停止");
    }
    sleep(700);
    dismissQqKeyboard();
}

// 后备方案：兼容只有箭头图标、没有“发送”文字的按钮。
// 先按文字/无障碍描述查找；失败后，在输入框右侧及其下方的输入面板内寻找可点击控件。
function clickSendButton(input, pattern, fixedFallback) {
    if (clickNamedButton(pattern)) return true;
    if (!input) return false;

    var ib = input.bounds();
    var inputPkg = String(input.packageName() || "");
    var screenW = device.width;
    var screenH = device.height;
    var nodes = classNameMatches(/.*/).find();
    var best = null;
    var bestScore = -Infinity;

    for (var i = 0; i < nodes.size(); i++) {
        var n = nodes.get(i);
        if (!n || !n.visibleToUser() || !n.enabled() || !n.clickable()) continue;
        // Compose 子控件有时不返回包名；键盘弹出后 currentPackage() 也可能不可靠。
        var nodePkg = String(n.packageName() || "");
        if (nodePkg && inputPkg && nodePkg !== inputPkg) continue;

        var b = n.bounds();
        if (!b || b.width() <= 0 || b.height() <= 0) continue;
        if (b.width() > screenW * 0.35 || b.height() > screenH * 0.20) continue;

        // ChatGPT 的箭头位于文字编辑区域下方，所以允许向下扩展一个输入工具栏高度。
        var maxDown = Math.max(180, Math.min(320, ib.height() * 0.55));
        if (b.centerY() < ib.top - 60 || b.centerY() > ib.bottom + maxDown) continue;
        if (b.centerX() <= ib.centerX() || b.centerX() < screenW * 0.62) continue;

        var targetY = Math.min(screenH, ib.bottom + 55);
        var yDistance = Math.abs(b.centerY() - targetY);
        var areaPenalty = b.width() * b.height() * 0.001;
        var score = b.centerX() * 2 - yDistance - areaPenalty;
        if (score > bestScore) {
            best = n;
            bestScore = score;
        }
    }

    if (best && best.click()) return true;

    // P50e 专用兜底：控件树完全不暴露发送箭头时，按当前屏幕比例点击。
    // 比例取自 696×1536 截图中的发送键中心 (623, 945)，可适配同纵横比的系统缩放。
    if (fixedFallback && inputPkg === CFG.chatgptPackage && String(input.text() || "").trim()) {
        var x = Math.round(device.width * fixedFallback.xRatio);
        var y = Math.round(device.height * fixedFallback.yRatio);
        logLine("控件识别失败，使用P50e固定比例发送点：" + x + "," + y);
        return click(x, y);
    }
    return false;
}

function clickNamedButton(pattern) {
    var selectors = [textMatches(pattern), descMatches(pattern)];
    for (var i = 0; i < selectors.length; i++) {
        var nodes = selectors[i].find();
        for (var j = nodes.size() - 1; j >= 0; j--) {
            var n = nodes.get(j);
            if (!n || !n.visibleToUser() || !n.enabled()) continue;
            if (n.click()) return true;
            var p = n.parent();
            if (p && p.clickable() && p.click()) return true;
        }
    }
    return false;
}

// v0.4.2：实测ChatGPT发送键desc为“发送消息”，但clickable=false。
// 锁定该节点后读取实时bounds，优先逐级点击父容器，最后点击节点中心。
function clickChatGptSend() {
    var nodes;
    try {
        nodes = packageName(CFG.chatgptPackage).desc("发送消息").find();
    } catch (_) {
        return false;
    }
    for (var i = nodes.size() - 1; i >= 0; i--) {
        var n = nodes.get(i);
        if (!n || !n.visibleToUser() || !n.enabled()) continue;

        var p = n;
        for (var depth = 0; p && depth < 8; depth++) {
            if (p.clickable() && p.enabled() && p.click()) return true;
            p = p.parent();
        }

        var b = n.bounds();
        if (b && b.width() > 0 && b.height() > 0 && click(b.centerX(), b.centerY())) {
            logLine("已按发送消息节点中心点击：" + b.centerX() + "," + b.centerY());
            return true;
        }
    }
    return false;
}

// 只允许通过明确的“回到底部/新消息/未读消息”按钮回到最新位置。
// 不执行任何 swipe 或坐标滑动；找不到明确按钮就保持当前页面不动。
function ensureQqAtBottom() {
    if (!isQqPageActive()) return false;
    var pattern = /^(回到底部|返回底部|跳到最新|查看最新消息|\d+条新消息|\d+条未读消息)$/;
    var clicked = false;
    try {
        var selectors = [textMatches(pattern), descMatches(pattern)];
        for (var k = 0; k < selectors.length && !clicked; k++) {
            var ns = selectors[k].find();
            for (var i = 0; i < ns.size(); i++) {
                var n = ns.get(i);
                if (!n || !n.visibleToUser()) continue;
                var p = n;
                for (var d = 0; p && d < 3; d++, p = p.parent()) {
                    if (p.clickable() && p.click()) { clicked = true; break; }
                }
            }
        }
    } catch (e) {
        logLine("定位聊天底部按钮失败：" + e);
    }
    if (clicked) sleep(280);
    return clicked;
}

// OCR 只裁剪输入框上方区域；旧的80.5%固定限制会漏掉最下方新消息，已移除。
function getQqOcrRegion(imgW, imgH) {
    var b = getQqInputBounds();
    if (!b) return null;
    var scale = imgH / Math.max(1, device.height);
    var top = Math.floor(imgH * CFG.chatTopRatio);
    var inputTop = Math.floor(b.top * scale);
    var margin = Math.max(8, Math.round(CFG.chatInputGapPx * scale));
    var bottom = Math.min(Math.floor(imgH * 0.975), inputTop - margin);
    if (bottom - top < imgH * CFG.minChatAreaRatio) return null;
    return { left: 0, top: top, width: imgW, height: bottom - top,
             bottom: bottom, inputTop: inputTop };
}

function readQqScreen() {
    if (!isQqPageActive()) return { valid: false, lines: [], signature: "" };
    var img = captureScreen();
    if (!img) throw new Error("截图失败");
    var clip = null, raw, region;
    try {
        var w = img.getWidth(), h = img.getHeight();
        region = getQqOcrRegion(w, h);
        if (!region) return { valid: false, lines: [], signature: "" };
        clip = images.clip(img, region.left, region.top, region.width, region.height);
        ocr.mode = "mlkit";
        raw = ocr.detect(clip);
    } finally {
        if (clip) { try { clip.recycle(); } catch (_) {} }
        try { img.recycle(); } catch (_) {}
    }
    var lines = normalizeOcr(raw);
    if (!lines.length) return { valid: false, lines: [], signature: "", region: region };
    return { valid: true, lines: lines,
        signature: hashString(lines.join("\n")), region: region };
}

function normalizeOcr(raw) {
    if (!raw) return [];
    var arr = Array.isArray(raw) ? raw : (raw.results || raw.data || []);
    var out = [];
    for (var i = 0; i < arr.length; i++) {
        var x = arr[i] || {};
        var t = String(x.text || x.label || x.words || x.value || "").trim().replace(/\s+/g, " ");
        if (!t || /^(发送|图片|相机|语音|表情|加号|返回)$/.test(t)) continue;
        var b = x.bounds || x.rect || x.boundingBox || {};
        var y = Number(b.top != null ? b.top : (Array.isArray(b) ? b[1] : i * 10));
        var x0 = Number(b.left != null ? b.left : (Array.isArray(b) ? b[0] : 0));
        out.push({ text: t, y: isNaN(y) ? i * 10 : y, x: isNaN(x0) ? 0 : x0 });
    }
    out.sort((a, b) => Math.abs(a.y - b.y) > 8 ? a.y - b.y : a.x - b.x);
    return out.map(x => x.text).slice(-CFG.maxOcrLines);
}

function ensureOcrReady() {
    try {
        if (!ocr || typeof ocr.detect !== "function") throw 0;
        ocr.mode = "mlkit";
    } catch (_) {
        throw new Error("AutoJs6 内置 ML Kit OCR 不可用，请确认使用 AutoJs6 6.7.0 后重启应用");
    }
}

function testOcr() {
    try {
        if (!getCapturePermission()) throw new Error("没有截图权限");
        ensureOcrReady();
        app.launchPackage(CFG.qqPackage);
        waitForPackage(CFG.qqPackage, 12000);
        sleep(CFG.appSwitchWaitMs);
        ensureQqAtBottom();
        var shot = readQqScreen();
        var range = shot.region ? ("识别区域：Y=" + shot.region.top + "～" + shot.region.bottom + "；输入框顶部Y=" + shot.region.inputTop + "\n\n") : "无法定位QQ聊天输入框，本次未进行OCR。请打开目标群聊。\n\n";
        dialogs.alert("OCR 测试结果", range + (shot.lines.length ? shot.lines.join("\n") : "没有识别到聊天文字"));
    } catch (e) { dialogs.alert("OCR 测试失败", String(e)); }
}

function findQqEditable() {
    try {
        var nodes = packageName(CFG.qqPackage)
            .className("android.widget.EditText").visibleToUser(true).find();
        for (var i = nodes.size() - 1; i >= 0; i--) {
            var n = nodes.get(i);
            if (!n || !n.enabled()) continue;
            var b = n.bounds();
            if (b && b.top > device.height * 0.27) return n;
        }
    } catch (_) {}
    return null;
}

function findEditable() {
    var nodes = className("android.widget.EditText").find();
    for (var i = nodes.size() - 1; i >= 0; i--) {
        var n = nodes.get(i);
        if (n && n.visibleToUser() && n.enabled()) return n;
    }
    return null;
}

function collectVisibleValues() {
    var values = [], nodes = classNameMatches(/.*/).find();
    for (var i = 0; i < nodes.size(); i++) {
        var n = nodes.get(i);
        if (!n || !n.visibleToUser()) continue;
        var s = String(n.text() || n.desc() || "").trim();
        if (s) values.push(s);
    }
    return values;
}

function hashString(s) {
    var h = 2166136261;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return (h >>> 0).toString(16);
}

function logLine(s) {
    try {
        files.ensureDir(CFG.logFile);
        files.append(CFG.logFile, new Date().toLocaleString() + "  " + s + "\n");
    } catch (_) {}
}




